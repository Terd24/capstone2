<!-- Alert Suppressor Script -->
<script src="remove_alerts.js"></script>
