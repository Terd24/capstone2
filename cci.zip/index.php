<?php
// Main entry point - redirect to login
header("Location: StudentLogin/login.php");
exit;
?>
