<?php
// This file handles adding new employees and optionally creating accounts
// Note: session_start() is handled by the calling file (Dashboard.php)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include '../StudentLogin/db_conn.php';
include '../includes/log_system_notification.php';

// Note: generateNextEmployeeId() function is defined in Dashboard.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Auto-generate Employee ID
    $id_number = generateNextEmployeeId($conn);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name']);
    $position = trim($_POST['position']);
    $department = trim($_POST['department']);
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $hire_date = $_POST['hire_date'];
    $create_account = isset($_POST['create_account']);
    $rfid_uid = trim($_POST['rfid_uid'] ?? ''); // required RFID for all employees (10 digits)
    
    // Account information (if creating account)
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    // Validate complete address (same as registrar)
    $validation_errors = [];
    if (strlen($address) < 20) {
        $validation_errors[] = "Complete address must be at least 20 characters long.";
    } elseif (strlen($address) > 500) {
        $validation_errors[] = "Complete address must not exceed 500 characters.";
    } else {
        // Validate address has at least 4 components separated by commas
        $addressParts = array_filter(array_map('trim', explode(',', $address)), function($part) {
            return strlen($part) > 0;
        });
        if (count($addressParts) < 4) {
            $validation_errors[] = "Complete address must include at least 4 components separated by commas (e.g., Street, Barangay, City, Province)";
        }
    }
    
    if (!empty($validation_errors)) {
        $_SESSION['error_msg'] = implode(' ', $validation_errors);
        $_SESSION['show_modal'] = true;
        $_SESSION['form_data'] = $_POST;
        header("Location: Dashboard.php");
        exit;
    }

    try {
        // Start transaction
        $conn->begin_transaction();

        // Ensure employees table exists (and required columns)
        $table_check = $conn->query("SHOW TABLES LIKE 'employees'");
        if ($table_check->num_rows == 0) {
            $create_employees_table = "CREATE TABLE employees (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_number VARCHAR(20) UNIQUE NOT NULL,
                first_name VARCHAR(50) NOT NULL,
                middle_name VARCHAR(50),
                last_name VARCHAR(50) NOT NULL,
                position VARCHAR(100) NOT NULL,
                department VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                address TEXT NOT NULL,
                rfid_uid VARCHAR(20) NOT NULL,
                hire_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";
            $conn->query($create_employees_table);
        } else {
            // Add missing columns if needed
            $column_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'hire_date'");
            if ($column_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN hire_date DATE NOT NULL DEFAULT '2024-01-01'");
            }
            $rfid_col_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'rfid_uid'");
            if ($rfid_col_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN rfid_uid VARCHAR(20) NULL");
            }
            $middle_name_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'middle_name'");
            if ($middle_name_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN middle_name VARCHAR(50) NULL AFTER first_name");
            }
            $address_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'address'");
            if ($address_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN address TEXT NULL");
            }
            
            // Update id_number column to support new format (CCI2025-001)
            $conn->query("ALTER TABLE employees MODIFY COLUMN id_number VARCHAR(20) UNIQUE NOT NULL");
        }

        // Validations
        $validation_errors = [];
        
        // Employee ID is auto-generated, no validation needed
        
        // Name validations
        if (empty($first_name) || trim($first_name) === '') {
            $validation_errors[] = "First name is required.";
        }
        if (empty($last_name) || trim($last_name) === '') {
            $validation_errors[] = "Last name is required.";
        }
        if (empty($position) || trim($position) === '') {
            $validation_errors[] = "Position is required.";
        }
        if (empty($department) || trim($department) === '') {
            $validation_errors[] = "Department is required.";
        }
        
        // Email validation
        if (empty($email) || trim($email) === '') {
            $validation_errors[] = "Email is required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $validation_errors[] = "Please enter a valid email address.";
        } else {
            // Validate email domain - only allow trusted providers
            $allowedDomains = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'icloud.com', 'protonmail.com', 'aol.com', 'zoho.com', 'mail.com', 'yandex.com', 'gmx.com', 'tutanota.com'];
            $emailDomain = strtolower(substr(strrchr($email, "@"), 1));
            if (!in_array($emailDomain, $allowedDomains)) {
                $validation_errors[] = "Please use a valid email provider (Gmail, Yahoo, Outlook, etc.)";
            }
        }
        
        // Phone validation - strip formatting first
        if (empty($phone) || trim($phone) === '') {
            $validation_errors[] = "Phone number is required.";
        } else {
            // Remove all non-digit characters for validation
            $phone_digits = preg_replace('/[^0-9]/', '', $phone);
            
            // Check if it's a valid Philippine number (should be 12 digits with country code: 63XXXXXXXXXX)
            if (strlen($phone_digits) !== 12 || !preg_match('/^639/', $phone_digits)) {
                $validation_errors[] = "Phone must be a valid Philippine mobile number (+63 9XX-XXX-XXXX).";
            }
            
            // Store the cleaned phone number for database insertion
            $phone = $phone_digits;
        }
        
        // Address validation
        if (empty($address) || trim($address) === '') {
            $validation_errors[] = "Complete address is required.";
        }
        
        // Hire date validation
        if (empty($hire_date)) {
            $validation_errors[] = "Hire date is required.";
        }
        
        // If there are validation errors, throw exception with all errors
        if (!empty($validation_errors)) {
            throw new Exception(implode('<br>', $validation_errors));
        }
        // RFID validation - only required for teachers
        if ($role === 'teacher') {
            if (empty($rfid_uid) || !preg_match('/^[0-9]{10}$/', $rfid_uid)) {
                throw new Exception("RFID must be exactly 10 digits (numbers only) for teacher accounts.");
            }
        } else {
            // For non-teachers, RFID is optional but if provided must be valid
            if (!empty($rfid_uid) && !preg_match('/^[0-9]{10}$/', $rfid_uid)) {
                throw new Exception("RFID must be exactly 10 digits (numbers only) if provided.");
            }
        }

        // Insert employee (set RFID to NULL if empty for non-teachers)
        $rfid_value = ($role !== 'teacher' && empty($rfid_uid)) ? null : $rfid_uid;
        $stmt = $conn->prepare("INSERT INTO employees (id_number, first_name, middle_name, last_name, position, department, email, phone, address, rfid_uid, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssssss", $id_number, $first_name, $middle_name, $last_name, $position, $department, $email, $phone, $address, $rfid_value, $hire_date);
        if (!$stmt->execute()) {
            throw new Exception("Failed to add employee: " . $stmt->error);
        }

        // Optionally create a system account
        if ($create_account && $username && $password && $role) {
            if ($role === 'hr') {
                throw new Exception("Creating HR accounts is not allowed.");
            }

            // Ensure employee_accounts table exists
            $account_table_check = $conn->query("SHOW TABLES LIKE 'employee_accounts'");
            if ($account_table_check->num_rows == 0) {
                $create_accounts_table = "CREATE TABLE employee_accounts (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    employee_id VARCHAR(20) NOT NULL,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    role ENUM('registrar','cashier','guidance','attendance','hr','teacher','department_head') NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (employee_id) REFERENCES employees(id_number) ON DELETE CASCADE
                )";
                $conn->query($create_accounts_table);
            }
            // Ensure ENUM includes all roles including department_head
            $roleColumn = $conn->query("SHOW COLUMNS FROM employee_accounts LIKE 'role'")->fetch_assoc();
            if ($roleColumn && isset($roleColumn['Type'])) {
                if (strpos($roleColumn['Type'], "'department_head'") === false) {
                    $conn->query("ALTER TABLE employee_accounts MODIFY role ENUM('registrar','cashier','guidance','attendance','hr','teacher','department_head') NOT NULL");
                }
            }

            // Hash password and insert
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $account_stmt = $conn->prepare("INSERT INTO employee_accounts (employee_id, username, password, role) VALUES (?, ?, ?, ?)");
            $account_stmt->bind_param("ssss", $id_number, $username, $hashed_password, $role);
            if (!$account_stmt->execute()) {
                throw new Exception("Failed to create account: " . $account_stmt->error);
            }
        }

        // Commit transaction
        $conn->commit();

        // Log system notification for Owner
        try {
            $employee_name = $first_name . ' ' . $last_name;
            $hr_name = $_SESSION['hr_name'] ?? 'HR Admin';
            $notif_title = "New Employee Added";
            $notif_message = formatActionMessage('employee_added', $employee_name, $id_number);
            
            $new_data = [
                'name' => $employee_name,
                'id_number' => $id_number,
                'position' => $position,
                'department' => $department,
                'has_account' => $create_account ? 'Yes' : 'No'
            ];
            
            logSystemNotification(
                $conn,
                $notif_title,
                $notif_message,
                'success',
                'HR',
                $hr_name,
                'HR',
                'employee_added',
                'employees',
                $id_number,
                null,
                $new_data
            );
        } catch (Exception $notif_error) {
            error_log("Error logging notification: " . $notif_error->getMessage());
        }

        $success_message = "Employee added successfully";
        if ($create_account) {
            $success_message .= " with system account";
        }
        $_SESSION['success_msg'] = $success_message;
        
        // Redirect to prevent form resubmission on refresh (Post/Redirect/Get pattern)
        header("Location: Dashboard.php");
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_msg'] = $e->getMessage();
        $_SESSION['show_modal'] = true;
        $_SESSION['form_data'] = $_POST;
        error_log("Employee creation error: " . $e->getMessage());
        error_log("POST data: " . print_r($_POST, true));
        
        // Redirect to prevent form resubmission on refresh
        header("Location: Dashboard.php");
        exit;
    }
}
?>