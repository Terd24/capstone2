<?php
session_start();
include("../StudentLogin/db_conn.php");

// Require HR login or Super Admin access
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['hr', 'superadmin'])) {
    header("Location: ../StudentLogin/login.php");
    exit;
}

// Prevent caching (so back button after logout doesn't show dashboard)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// Function to generate next Employee ID
function generateNextEmployeeId($conn) {
    $currentYear = date('Y');
    $prefix = 'CCI' . $currentYear . '-';
    
    // Get the highest existing employee ID for current year
    $query = "SELECT id_number FROM employees WHERE id_number LIKE ? ORDER BY id_number DESC LIMIT 1";
    $stmt = $conn->prepare($query);
    $searchPattern = $prefix . '%';
    $stmt->bind_param("s", $searchPattern);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastId = $row['id_number'];
        // Extract the numeric part after the dash
        $parts = explode('-', $lastId);
        if (count($parts) == 2) {
            $numericPart = intval($parts[1]);
            $nextNumber = $numericPart + 1;
        } else {
            $nextNumber = 1;
        }
    } else {
        // First employee for this year
        $nextNumber = 1;
    }
    
    // Format as CCI2025-001, CCI2025-002, etc.
    return $prefix . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
}

// Handle form submission (like registrar)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include("add_employee.php");
}

// Generate next Employee ID for display
$next_employee_id = generateNextEmployeeId($conn);

// Handle error and success messages
$error_msg = $_SESSION['error_msg'] ?? '';
$success_msg = $_SESSION['success_msg'] ?? '';
$show_modal = $_SESSION['show_modal'] ?? false;
$form_data = $_SESSION['form_data'] ?? [];

if ($error_msg) {
    unset($_SESSION['error_msg']);
}
if ($success_msg) {
    unset($_SESSION['success_msg']);
}
if (isset($_SESSION['show_modal'])) {
    unset($_SESSION['show_modal']);
}
if (isset($_SESSION['form_data'])) {
    unset($_SESSION['form_data']);
}

// Ensure soft delete columns exist
$conn->query("ALTER TABLE employees ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP NULL DEFAULT NULL");
$conn->query("ALTER TABLE employees ADD COLUMN IF NOT EXISTS deleted_by VARCHAR(255) NULL");
$conn->query("ALTER TABLE employees ADD COLUMN IF NOT EXISTS deleted_reason TEXT NULL");

// Get requester name for checking pending requests
$requester_name = $_SESSION['hr_name'] ?? $_SESSION['username'] ?? 'HR Staff';

// Debug: Output session info (remove after testing)
error_log("HR Dashboard - Session hr_name: " . ($_SESSION['hr_name'] ?? 'NOT SET'));
error_log("HR Dashboard - Session username: " . ($_SESSION['username'] ?? 'NOT SET'));
error_log("HR Dashboard - Requester name: " . $requester_name);

// Get pending deletion requests for this HR user
$pending_deletions = [];
$pending_query = "SELECT target_id, target_data FROM owner_approval_requests 
                  WHERE status = 'pending' 
                  AND requester_name = ? 
                  AND (request_type = 'hr_employee_deletion' OR request_type = 'delete_hr_employee')";
$pending_stmt = $conn->prepare($pending_query);
$pending_stmt->bind_param("s", $requester_name);
$pending_stmt->execute();
$pending_result = $pending_stmt->get_result();
while ($pending_row = $pending_result->fetch_assoc()) {
    $target_data = $pending_row['target_data'] ? json_decode($pending_row['target_data'], true) : [];
    $employee_id = $target_data['employee_id'] ?? $pending_row['target_id'];
    if ($employee_id) {
        $pending_deletions[] = $employee_id;
    }
}
$pending_stmt->close();

// Fetch only active employees (not soft-deleted) excluding HR department
// HR staff cannot see or edit HR employees - only Super Admin can manage HR accounts
$result = $conn->query("SELECT id_number, CONCAT(first_name, ' ', last_name) as full_name, position, department, 
                       (SELECT username FROM employee_accounts WHERE employee_accounts.employee_id = employees.id_number) as username 
                       FROM employees WHERE deleted_at IS NULL AND department != 'Human Resources' ORDER BY id_number ASC");

// Get total active employee count (excluding HR department)
$count_result = $conn->query("SELECT COUNT(*) as total_employees FROM employees WHERE deleted_at IS NULL AND department != 'Human Resources'");
$total_employees = $count_result->fetch_assoc()['total_employees'];

$columns = ['ID Number', 'Full Name', 'Position', 'Department', 'Account Status'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee Management - CCI</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
input[type=number] { -moz-appearance: textfield; }

/* Hide scrollbars */
.no-scrollbar {
    -ms-overflow-style: none;  /* Internet Explorer 10+ */
    scrollbar-width: none;  /* Firefox */
}
.no-scrollbar::-webkit-scrollbar { 
    display: none;  /* Safari and Chrome */
}

/* Reset Password Button styles */
button[id^="resetPasswordBtn_"]:not([disabled]) {
    background-color: #eab308 !important;
    cursor: pointer !important;
}
button[id^="resetPasswordBtn_"]:not([disabled]):hover {
    background-color: #ca8a04 !important;
}
button[id^="resetPasswordBtn_"][disabled] {
    background-color: #9ca3af !important;
    cursor: not-allowed !important;
}
</style>
<script src="../js/logout-confirm.js"></script>
</head>
<body class="bg-gradient-to-br from-[#f3f6fb] to-[#e6ecf7] font-sans min-h-screen text-gray-900">

<header class="bg-[#0B2C62] text-white shadow-lg">
  <div class="container mx-auto px-6 py-4">
    <div class="flex justify-between items-center">
      <div class="flex items-center space-x-4">
        <div class="text-left">
          <p class="text-sm text-blue-200">Welcome,</p>
          <p class="font-semibold"><?= htmlspecialchars($_SESSION['hr_name'] ?? 'HR User') ?></p>
        </div>

<!-- Delete Employee (entire record) Confirmation Modal -->
<div id="deleteEmployeeModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center" style="z-index:11000;">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
        <div class="flex flex-col items-center text-center">
            <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mb-3">
                <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01M5.07 19h13.86A2 2 0 0021 17.13L13.93 4.87a2 2 0 00-3.86 0L3 17.13A2 2 0 005.07 19z" />
                </svg>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">Delete Employee</h3>
            <p class="text-gray-600 mb-6">Are you sure you want to delete this employee record? This will also remove their system accounts and cannot be undone.</p>
            <div class="flex w-full gap-3">
                <button onclick="closeDeleteEmployeeConfirmation()" class="flex-1 py-2.5 rounded-lg bg-gray-200 text-gray-800 hover:bg-gray-300 font-medium">Cancel</button>
                <button id="confirmDeleteEmployeeBtn" class="flex-1 py-2.5 rounded-lg bg-red-600 text-white hover:bg-red-700 font-medium">Delete</button>
            </div>
        </div>
    </div>
    
</div>
      </div>
      
      <div class="flex items-center space-x-4">
        <img src="../images/LogoCCI.png" alt="Cornerstone College Inc." class="h-12 w-12 rounded-full bg-white p-1">
        <div class="text-right">
          <h1 class="text-xl font-bold">Cornerstone College Inc.</h1>
          <p class="text-blue-200 text-sm">HR Portal</p>
        </div>
        <div class="relative">
          <button id="menuBtn" class="bg-white bg-opacity-20 hover:bg-opacity-30 p-2 rounded-lg transition">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
          <div id="dropdownMenu" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg z-50 text-gray-800">
            <a href="javascript:void(0);" onclick="showLogoutConfirmation('logout.php');" class="block px-4 py-3 hover:bg-gray-100 rounded-lg">
              <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
              </svg>
              Logout
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>

<div class="max-w-7xl mx-auto mt-8 p-6">

    <!-- Header Section with Title and Employee Count -->
    <div class="mb-6">
        <div class="flex items-center gap-4">
            <h2 class="text-2xl font-bold text-[#0B2C62]">Employee Management</h2>
            <div class="flex items-center gap-2 bg-[#0B2C62] text-white px-4 py-2 rounded-lg shadow-sm">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                </svg>
                <span class="text-sm font-semibold">Total: <?= $total_employees ?></span>
            </div>
        </div>
    </div>

    <!-- Controls Section -->
    <div class="flex flex-col sm:flex-row gap-4 sm:items-center justify-between mb-6 bg-white p-4 rounded-xl shadow-sm border border-[#0B2C62]/10">
        <div class="flex items-center gap-3">
            <!-- Pagination will be shown here after table -->
        </div>
        
        <div class="flex items-center gap-3">
            <input type="text" id="searchInput" placeholder="Search by name or ID..." class="w-full sm:w-64 border border-[#0B2C62]/30 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] placeholder-gray-400"/>
            <button onclick="openModal()" class="px-4 py-2 bg-green-500 text-white rounded-lg shadow hover:bg-green-600 transition flex items-center gap-2 font-medium whitespace-nowrap">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                </svg>
                Add Employee
            </button>
        </div>
    </div>

    <!-- Employees Table -->
    <div class="overflow-x-auto bg-white shadow-lg rounded-2xl p-4 border border-blue-200">
        <table class="min-w-full text-sm border-collapse">
            <thead class="bg-[#0B2C62] text-white">
                <tr>
                    <?php foreach($columns as $col): ?>
                        <th class="px-4 py-3 border text-left font-semibold"><?= $col ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody id="employeeTable" class="divide-y divide-gray-200">
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php 
                        $has_pending = in_array($row['id_number'], $pending_deletions);
                        $row_class = $has_pending ? 'hover:bg-blue-50 transition cursor-pointer bg-orange-50 border-l-4 border-orange-500' : 'hover:bg-blue-50 transition cursor-pointer';
                        ?>
                        <tr class="<?= $row_class ?>" onclick="viewEmployee('<?= $row['id_number'] ?>')">
                            <td class="px-4 py-3">
                                <?= htmlspecialchars($row['id_number']) ?>
                                <?php if ($has_pending): ?>
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-orange-100 text-orange-800 ml-2">
                                        <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/>
                                        </svg>
                                        Pending Deletion
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3"><?= htmlspecialchars($row['full_name']) ?></td>
                            <td class="px-4 py-3"><?= htmlspecialchars($row['position']) ?></td>
                            <td class="px-4 py-3"><?= htmlspecialchars($row['department']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= $row['username'] ? '<span class="px-2 py-1 bg-green-500 text-white rounded text-xs">Has Account</span>' : '<span class="px-2 py-1 bg-gray-500 text-white rounded text-xs">No Account</span>' ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?= count($columns) ?>" class="px-4 py-6 text-center text-gray-500 italic">No employees found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination Controls -->
    <div id="paginationBar" class="mt-4 flex items-center justify-center gap-2 text-sm">
        <button id="prevPage" class="px-3 py-1 border rounded-lg text-[#0B2C62] hover:bg-[#0B2C62] hover:text-white disabled:opacity-40 transition">Prev</button>
        <span id="pageInfo" class="px-2 text-gray-600">Page 1 of 1</span>
        <button id="nextPage" class="px-3 py-1 border rounded-lg text-[#0B2C62] hover:bg-[#0B2C62] hover:text-white disabled:opacity-40 transition">Next</button>
    </div>
</div>

<!-- View Employee Modal -->
<div id="viewEmployeeModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
    <div class="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden border-2 border-[#0B2C62] transform transition-all scale-100">
        <div class="flex justify-between items-center border-b border-gray-200 px-6 py-4 bg-[#0B2C62] rounded-t-2xl">
            <h2 class="text-lg font-semibold text-white">Employee Information</h2>
            <div class="flex flex-col items-end gap-1">
                <div class="flex gap-3">
                    <!-- Edit mode buttons (hidden by default) -->
                    <button id="saveChangesBtn" onclick="saveEmployeeChanges()" class="hidden px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition">Save Changes</button>
                    <button id="cancelEditBtn" onclick="cancelEdit()" class="hidden px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition">Cancel</button>
                    
                    <!-- View mode buttons -->
                    <button id="editEmployeeBtn" onclick="toggleEditMode()" class="px-4 py-2 bg-[#2F8D46] text-white rounded-lg hover:bg-[#256f37] transition">Edit</button>
                    <button id="deleteEmployeeBtn" onclick="showDeleteEmployeeConfirmation(getCurrentEmployeeId())" class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition">Delete Employee</button>
                    <button onclick="closeViewModal()" class="text-2xl font-bold text-white hover:text-gray-300">&times;</button>
                </div>
            </div>
        </div>
        <div class="px-6 py-6 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto max-h-[80vh] no-scrollbar" id="employeeDetailsContent">
            <!-- Content will be populated by JavaScript -->
        </div>
    </div>
</div>

<!-- Edit Employee Modal -->
<div id="editEmployeeModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div class="bg-[#0B2C62] text-white p-6 rounded-t-2xl">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold">Edit Employee</h3>
                <button onclick="closeEditModal()" class="text-white hover:text-gray-300">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        <form id="editEmployeeForm" class="p-6">
            <div id="editEmployeeContent">
                <!-- Content will be populated by JavaScript -->
            </div>
            <div class="flex justify-end gap-3 mt-6">
                <button type="button" onclick="closeEditModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-[#0B2C62] text-white rounded-lg hover:bg-[#0B2C62]/90 transition">Update Employee</button>
            </div>
        </form>
    </div>
</div>

<!-- Removed duplicate static Create Account Modal to avoid ID conflicts. The dynamic modal below is the single source of truth. -->

<!-- Add Employee Modal -->
<div id="addEmployeeModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
    <div class="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden border-2 border-[#0B2C62] transform transition-all scale-100">
        
        <!-- Header -->
        <div class="flex justify-between items-center border-b border-gray-200 px-6 py-4 bg-[#0B2C62] rounded-t-2xl">
            <h2 class="text-lg font-semibold text-white">Add New Employee</h2>
            <button onclick="closeModal()" class="text-2xl font-bold text-white hover:text-gray-300">&times;</button>
        </div>

        <!-- Error Messages -->
        <?php if (!empty($error_msg)): ?>
            <div class="mx-6 mt-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                <?= $error_msg ?>
            </div>
        <?php endif; ?>

        <!-- Form -->
        <form method="POST" action="" autocomplete="off" novalidate class="px-6 py-6 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto max-h-[80vh] no-scrollbar">
            
            <!-- Personal Information Section -->
            <div class="col-span-3 mb-6">
                <div class="bg-gray-50 border-2 border-gray-400 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        PERSONAL INFORMATION
                    </h3>
                    <div class="grid grid-cols-3 gap-6">
                        
                        <div>
                            <label class="block text-sm font-semibold mb-1">First Name *</label>
                            <input type="text" name="first_name" autocomplete="off" pattern="[A-Za-z\s]+" maxlength="20" title="Letters only, maximum 20 characters" required value="<?= htmlspecialchars($form_data['first_name'] ?? '') ?>" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] name-input">
                        </div>
                                                 <div>
                            <label class="block text-sm font-semibold mb-1">Last Name *</label>
                            <input type="text" name="last_name" autocomplete="off" pattern="[A-Za-z\s]+" maxlength="20" title="Letters only, maximum 20 characters" required value="<?= htmlspecialchars($form_data['last_name'] ?? '') ?>" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] name-input">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold mb-1">Middle Name <span class="text-gray-500 text-xs">(Optional)</span></label>
                            <input type="text" name="middle_name" autocomplete="off" pattern="[A-Za-z\s]*" maxlength="20" title="Letters only, maximum 20 characters" value="<?= htmlspecialchars($form_data['middle_name'] ?? '') ?>" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] name-input">
                        </div>

                                                <div>
                            <label class="block text-sm font-semibold mb-1">Employee ID <span class="text-gray-500 text-xs">(Auto-generated)</span></label>
                            <input type="text" name="id_number" autocomplete="off" value="<?= htmlspecialchars($form_data['id_number'] ?? $next_employee_id) ?>" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] bg-gray-100 cursor-not-allowed" style="background-color:#f3f4f6;">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold mb-1">Position *</label>
                            <input type="text" name="position" autocomplete="off" pattern="[A-Za-z\s]+" maxlength="20" title="Letters only, maximum 20 characters" required value="<?= htmlspecialchars($form_data['position'] ?? '') ?>" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] name-input">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Department *</label>
                            <select name="department" required class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
                                <option value="">-- Select Department --</option>
                                <option value="Academic Affairs" <?= ($form_data['department'] ?? '') === 'Academic Affairs' ? 'selected' : '' ?>>Academic Affairs</option>
                                <option value="Student Affairs" <?= ($form_data['department'] ?? '') === 'Student Affairs' ? 'selected' : '' ?>>Student Affairs</option>
                                <option value="Finance" <?= ($form_data['department'] ?? '') === 'Finance' ? 'selected' : '' ?>>Finance</option>
                                <option value="Human Resources" <?= ($form_data['department'] ?? '') === 'Human Resources' ? 'selected' : '' ?>>Human Resources</option>
                                <option value="IT Department" <?= ($form_data['department'] ?? '') === 'IT Department' ? 'selected' : '' ?>>IT Department</option>
                                <option value="Maintenance" <?= ($form_data['department'] ?? '') === 'Maintenance' ? 'selected' : '' ?>>Maintenance</option>
                                <option value="Security" <?= ($form_data['department'] ?? '') === 'Security' ? 'selected' : '' ?>>Security</option>
                            </select>
                        </div>
                        
                        <!-- Row 3: Hire Date and Phone -->
                        <div>
                            <label class="block text-sm font-semibold mb-1">Hire Date *</label>
                            <input type="date" name="hire_date" max="<?= date('Y-m-d') ?>" required value="<?= htmlspecialchars($form_data['hire_date'] ?? '') ?>" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold mb-1">Phone *</label>
                            <input type="tel" name="phone" id="phoneField" required placeholder="+63 9XX-XXX-XXXX" value="<?= htmlspecialchars($form_data['phone'] ?? '') ?>" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]" title="Please enter Philippine mobile number (e.g., +63 912-345-6789)" oninput="formatPhilippinePhone(this)">
                            <p class="field-error-message text-red-600 text-sm mt-1 font-medium hidden"></p>
                        </div>
                        
                        <div class="col-span-1"></div>
                        
                        <!-- Row 4: Email (full width with verify button) -->
                        <div class="col-span-3">
                            <label class="block text-sm font-semibold mb-1">Email *</label>
                            <div class="flex gap-2">
                                <input type="email" name="email" id="employeeEmail" autocomplete="off" required value="<?= htmlspecialchars($form_data['email'] ?? '') ?>" class="flex-1 border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]" pattern="[a-zA-Z0-9._%+-]+@gmail\.com$" title="Please enter a valid Gmail address">
                                <button type="button" id="verifyEmailBtn" onclick="sendVerificationCode()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition whitespace-nowrap">
                                    Verify Email
                                </button>
                            </div>
                            <p id="emailVerificationStatus" class="text-sm mt-1 font-medium hidden"></p>
                            <p class="field-error-message text-red-600 text-sm mt-1 font-medium hidden"></p>
                        </div>
                        

                        <!-- Complete Address -->
                        <div class="col-span-3">
                            <label class="block text-sm font-semibold mb-1">Complete Address *</label>
                            <textarea name="address" rows="3" autocomplete="off" required minlength="20" maxlength="500" placeholder="Enter complete address (e.g., Block 8, Lot 15, Subdivision Name, Barangay, City, Province)" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]" title="Please enter a complete address with at least 20 characters including street, barangay, city/municipality, and province."><?= htmlspecialchars($form_data['address'] ?? '') ?></textarea>
                            <p class="text-xs text-gray-500 mt-1">Minimum 20 characters. Include street, barangay, city/municipality, and province.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Account Section -->
            <div class="col-span-3 mb-6">
                <div class="bg-gray-50 border-2 border-gray-400 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                        SYSTEM ACCOUNT  
                    </h3>
                    
                    <div class="mb-4">
                        <div class="flex items-center gap-2 select-none">
                            <input type="checkbox" id="createAccount" name="create_account" class="rounded border-gray-300 text-[#0B2C62] focus:ring-[#0B2C62] cursor-pointer" aria-controls="accountFields">
                            <span class="text-sm font-medium text-gray-700 pointer-events-none">Create system account for this employee</span>
                        </div>
                    </div>
                    
                    <div id="accountFields" class="hidden">
                        <div class="grid grid-cols-3 gap-6 mb-4">
                            <div>
                                <label class="block text-sm font-semibold mb-1">Username <span class="text-gray-500 text-xs">(Auto-generated)</span></label>
                                <input type="text" id="usernameField" name="username" autocomplete="off" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] bg-gray-100 cursor-not-allowed" style="background-color:#f3f4f6;">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-1">Password <span class="text-gray-500 text-xs">(Auto-generated)</span></label>
                                <input type="text" id="passwordField" name="password" autocomplete="new-password" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] bg-gray-100 cursor-not-allowed" style="background-color:#f3f4f6;">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-1">Role</label>
                                <select id="employeeRole" name="role" onchange="toggleRFIDField()" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
                                    <option value="">-- Select Role --</option>
                                    <option value="registrar">Registrar</option>
                                    <option value="cashier">Cashier</option>
                                    <option value="guidance">Guidance</option>
                                    <option value="attendance">Attendance</option>
                                    <option value="teacher">Teacher</option>
                                    <option value="department_head">Department Head</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- RFID Field - Only shown for Teacher role -->
                        <div id="rfidFieldContainer" class="hidden">
                            <div class="grid grid-cols-1 gap-6">
                                <div>
                                    <label class="block text-sm font-semibold mb-1">RFID Number *</label>
                                    <input type="text" id="rfid_uid" name="rfid_uid" autocomplete="off" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] rfid-input" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" title="Please enter exactly 10 digits (numbers only)" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10)">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit Buttons -->
            <div class="col-span-3 flex justify-end gap-4 pt-6 border-t border-gray-200">
                <button type="button" onclick="closeModal()" class="px-5 py-2 border border-blue-600 text-blue-900 rounded-xl hover:bg-[#0B2C62] hover:text-white transition">Cancel</button>
                <button type="button" onclick="confirmAddEmployee()" class="px-5 py-2 bg-green-600 text-white rounded-xl shadow hover:bg-green-700 transition">
                    Add Employee
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Notifications removed - using toast notifications instead -->

<!-- Edit Account Modal -->
<div id="editAccountModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-full max-w-md">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-semibold text-gray-800">Employee Details</h3>
            <div class="flex items-center gap-2">
                <button id="editEmployeeBtn" onclick="toggleEditMode()" class="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600">
                    Edit
                </button>
                <button onclick="closeViewModal()" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </div>
        <form id="editAccountForm" onsubmit="updateAccount(event)">
            <div id="editAccountContent">
                <!-- Content will be populated by JavaScript -->
            </div>
            <div class="flex justify-end gap-2 mt-6">
                <button type="button" onclick="closeEditAccountModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                    Update Account
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Create Account Modal -->
<div id="createAccountModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-full max-w-md">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-semibold text-gray-800">Create System Account</h3>
            <button onclick="closeCreateAccountModal()" class="text-gray-500 hover:text-gray-700">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
        <form id="createAccountForm" onsubmit="createNewAccount(event)" autocomplete="off">
            <div id="createAccountContent">
                <!-- Content will be populated by JavaScript -->
            </div>
            <div class="flex justify-end gap-2 mt-6">
                <button type="button" onclick="closeCreateAccountModal()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">
                    Create Account
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteConfirmationModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center" style="z-index:10090;">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
        <div class="flex flex-col items-center text-center">
            <div class="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mb-3">
                <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01M5.07 19h13.86A2 2 0 0021 17.13L13.93 4.87a2 2 0 00-3.86 0L3 17.13A2 2 0 005.07 19z" />
                </svg>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">Remove Login Access</h3>
            <p class="text-gray-600 mb-6">Are you sure you want to remove this employee's system account? The employee record will remain, but they will lose access to the system.</p>
            <div class="flex w-full gap-3">
                <button onclick="closeDeleteConfirmation()" class="flex-1 py-2.5 rounded-lg bg-gray-200 text-gray-800 hover:bg-gray-300 font-medium">Cancel</button>
                <button id="confirmDeleteBtn" class="flex-1 py-2.5 rounded-lg bg-red-600 text-white hover:bg-red-700 font-medium">Delete</button>
            </div>
        </div>
    </div>
</div>

<style>
/* Hide scrollbar for employee details content */
#employeeDetailsContent::-webkit-scrollbar {
    display: none;
}
</style>

<script>
// Show modal if there's an error
<?php if ($show_modal): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('addEmployeeModal').classList.remove('hidden');
});
<?php endif; ?>

// Show success toast if there's a success message
<?php if ($success_msg): ?>
document.addEventListener('DOMContentLoaded', function() {
    showToast('<?= addslashes($success_msg) ?>', 'success');
});
<?php endif; ?>

// Modal functions
function openModal() {
    document.getElementById('addEmployeeModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('addEmployeeModal').classList.add('hidden');
}

// Validation helper functions
function highlightFieldError(element, message) {
    if (!element) return;
    
    // Add red border and background
    element.classList.remove('border-gray-300', 'focus:ring-[#0B2C62]');
    element.classList.add('border-red-500', 'focus:ring-red-500', 'bg-red-50');
    
    // Create or update error message
    let errorMsg = element.parentElement.querySelector('.field-error-message');
    if (!errorMsg) {
        errorMsg = document.createElement('p');
        errorMsg.className = 'field-error-message text-red-600 text-sm mt-1 font-medium';
        element.parentElement.appendChild(errorMsg);
    }
    errorMsg.textContent = message;
    errorMsg.classList.remove('hidden');
    
    // Focus on first error field
    if (!document.querySelector('.border-red-500')) {
        element.focus();
    }
}

function clearFieldErrors(form) {
    if (!form) return;
    
    // Remove red borders and backgrounds
    const errorFields = form.querySelectorAll('.border-red-500');
    errorFields.forEach(field => {
        field.classList.remove('border-red-500', 'focus:ring-red-500', 'bg-red-50');
        field.classList.add('border-gray-300', 'focus:ring-[#0B2C62]');
    });
    
    // Hide error messages
    const errorMessages = form.querySelectorAll('.field-error-message');
    errorMessages.forEach(msg => {
        msg.classList.add('hidden');
        msg.textContent = '';
    });
}

function clearSingleFieldError(element) {
    if (!element) return;
    
    // Remove red border and background
    element.classList.remove('border-red-500', 'focus:ring-red-500', 'bg-red-50');
    element.classList.add('border-gray-300', 'focus:ring-[#0B2C62]');
    
    // Hide error message
    const errorMsg = element.parentElement.querySelector('.field-error-message');
    if (errorMsg) {
        errorMsg.classList.add('hidden');
        errorMsg.textContent = '';
    }
}

// Add input event listeners to clear errors when user types
function setupFieldValidationListeners() {
    const form = document.querySelector('#addEmployeeModal form');
    if (!form) return;
    
    // Get all input, select, and textarea elements
    const fields = form.querySelectorAll('input, select, textarea');
    
    fields.forEach(field => {
        // Clear error on input/change
        field.addEventListener('input', function() {
            if (this.classList.contains('border-red-500')) {
                clearSingleFieldError(this);
            }
        });
        
        field.addEventListener('change', function() {
            if (this.classList.contains('border-red-500')) {
                clearSingleFieldError(this);
            }
        });
    });
}

// Auto-generate username and password based on last name and employee ID
function generateUsernameAndPassword() {
    const form = document.querySelector('#addEmployeeModal form');
    if (!form) return;
    
    const lastNameField = form.querySelector('input[name="last_name"]');
    const employeeIdField = form.querySelector('input[name="id_number"]');
    const usernameField = document.getElementById('usernameField');
    const passwordField = document.getElementById('passwordField');
    
    if (!lastNameField || !employeeIdField || !usernameField || !passwordField) return;
    
    const lastName = lastNameField.value.trim().toLowerCase();
    const employeeId = employeeIdField.value.trim();
    
    if (lastName && employeeId) {
        // Extract the 3-digit number from employee ID (e.g., CCI2025-001 -> 001)
        const parts = employeeId.split('-');
        const idNumber = parts.length === 2 ? parts[1] : '000';
        
        // Get current year
        const currentYear = new Date().getFullYear();
        
        // Format username: lastname001muzon@employee.cci.edu.ph
        const username = lastName + idNumber + 'muzon@employee.cci.edu.ph';
        usernameField.value = username;
        
        // Format password: lastname0012025
        const password = lastName + idNumber + currentYear;
        passwordField.value = password;
    } else {
        usernameField.value = '';
        passwordField.value = '';
    }
}

// Setup username and password auto-generation
function setupUsernameAndPasswordGeneration() {
    const form = document.querySelector('#addEmployeeModal form');
    if (!form) return;
    
    const lastNameField = form.querySelector('input[name="last_name"]');
    
    if (lastNameField) {
        // Generate username and password when last name changes
        lastNameField.addEventListener('input', generateUsernameAndPassword);
        lastNameField.addEventListener('blur', generateUsernameAndPassword);
    }
    
    // Generate on page load if last name already has value
    generateUsernameAndPassword();
}

// Initialize field validation listeners when page loads
document.addEventListener('DOMContentLoaded', function() {
    setupFieldValidationListeners();
    setupUsernameAndPasswordGeneration();
});

// Show/hide account fields and RFID when needed
const createAccountChk = document.getElementById('createAccount');
const accountFields = document.getElementById('accountFields');
const roleSelect = document.getElementById('employeeRole');
const rfidField = document.getElementById('rfidField');
const rfidInput = document.getElementById('rfid_uid');

function updateAccountFieldsVisibility() {
    if (!createAccountChk || !accountFields) return;
    const show = createAccountChk.checked;
    accountFields.classList.toggle('hidden', !show);
    updateRFIDRequirement();
}

function toggleRFIDField() {
    const roleSelect = document.getElementById('employeeRole');
    const rfidContainer = document.getElementById('rfidFieldContainer');
    const rfidInput = document.getElementById('rfid_uid');
    
    if (!roleSelect || !rfidContainer || !rfidInput) return;
    
    const selectedRole = roleSelect.value;
    
    // Show RFID field only for Teacher role
    if (selectedRole === 'teacher') {
        rfidContainer.classList.remove('hidden');
        rfidInput.setAttribute('required', 'required');
    } else {
        rfidContainer.classList.add('hidden');
        rfidInput.removeAttribute('required');
        rfidInput.value = ''; // Clear the value when hidden
    }
}

function updateRFIDRequirement() {
    // Call the new toggle function
    toggleRFIDField();
}

// Toggle RFID field in Create Account modal
function toggleCreateAccountRFID() {
    const roleSelect = document.getElementById('ca_role');
    const rfidContainer = document.getElementById('ca_rfid_container');
    const rfidInput = document.getElementById('ca_rfid_uid');
    
    if (!roleSelect || !rfidContainer || !rfidInput) return;
    
    const selectedRole = roleSelect.value;
    
    // Show RFID field only for Teacher role
    if (selectedRole === 'teacher') {
        rfidContainer.classList.remove('hidden');
        rfidInput.setAttribute('required', 'required');
    } else {
        rfidContainer.classList.add('hidden');
        rfidInput.removeAttribute('required');
        rfidInput.value = ''; // Clear the value when hidden
    }
}

if (createAccountChk) createAccountFieldsBound = (createAccountChk.addEventListener('change', updateAccountFieldsVisibility), true);
if (roleSelect) roleSelect.addEventListener('change', updateRFIDRequirement);
try { updateAccountFieldsVisibility(); } catch(e) { /* no-op */ }

// Format Philippine phone number with +63 prefix
function formatPhilippinePhone(input) {
    // Remove all non-numeric characters except +
    let value = input.value.replace(/[^\d+]/g, '');
    
    // Remove + if it's not at the start
    if (value.indexOf('+') > 0) {
        value = value.replace(/\+/g, '');
    }
    
    // If starts with 0, convert to +63
    if (value.startsWith('0')) {
        value = '+63' + value.slice(1);
    }
    
    // If doesn't start with +63, add it
    if (!value.startsWith('+63') && !value.startsWith('+')) {
        value = '+63' + value;
    }
    
    // Ensure it starts with +63
    if (value.startsWith('+') && !value.startsWith('+63')) {
        value = '+63' + value.slice(1);
    }
    
    // Remove +63 prefix for processing
    let digits = value.replace('+63', '');
    
    // Limit to 10 digits (after +63)
    digits = digits.slice(0, 10);
    
    // Format as +63 9XX-XXX-XXXX
    let formatted = '+63';
    if (digits.length > 0) {
        formatted += ' ' + digits.slice(0, 3);
    }
    if (digits.length > 3) {
        formatted += '-' + digits.slice(3, 6);
    }
    if (digits.length > 6) {
        formatted += '-' + digits.slice(6, 10);
    }
    
    input.value = formatted;
}

// Show notification
document.addEventListener('DOMContentLoaded', function() {
    const notif = document.getElementById('notif');
    if (notif) {
        setTimeout(() => {
            notif.classList.remove('translate-x-full', 'opacity-0');
        }, 100);
        
        setTimeout(() => {
            notif.classList.add('translate-x-full', 'opacity-0');
        }, 3000);
    }
    
    const errorNotif = document.getElementById('error-notif');
    if (errorNotif) {
        setTimeout(() => {
            errorNotif.classList.remove('translate-x-full', 'opacity-0');
        }, 100);
        
        setTimeout(() => {
            errorNotif.classList.add('translate-x-full', 'opacity-0');
        }, 5000);
    }
});

// Employee view function
function viewEmployee(employeeId) {
    // Fetch employee details and show in modal
    fetch(`view_employee.php?id=${employeeId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showEmployeeDetailsModal(data.employee);
            } else {
                showToast('Error loading employee details: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Error loading employee details', 'error');
        });
}

// Show employee details modal
let currentEmployeeId = null;
async function showEmployeeDetailsModal(employee) {
    currentEmployeeId = employee.id_number;
    const content = document.getElementById('employeeDetailsContent');
    
    // Check if this employee has a pending deletion request
    let hasPendingDeletion = false;
    try {
        const response = await fetch('../AdminF/check_pending_requests.php');
        const data = await response.json();
        console.log('Pending requests data:', data);
        console.log('Current employee ID:', employee.id_number);
        console.log('Pending requests array:', data.pending_requests);
        console.log('Number of pending requests:', data.pending_requests ? data.pending_requests.length : 0);
        
        if (data.success && data.pending_requests && data.pending_requests.length > 0) {
            hasPendingDeletion = data.pending_requests.some(request => {
                console.log('Checking request:', request);
                console.log('Request type:', request.request_type);
                console.log('Request target_id:', request.target_id);
                console.log('Request target_data:', request.target_data);
                
                if (request.request_type === 'hr_employee_deletion' || request.request_type === 'delete_hr_employee') {
                    const targetData = request.target_data ? JSON.parse(request.target_data) : {};
                    const employeeId = targetData.employee_id || request.target_id;
                    console.log('Extracted employee ID:', employeeId);
                    console.log('Comparing:', employeeId, '===', employee.id_number);
                    console.log('Match:', employeeId === employee.id_number);
                    return employeeId === employee.id_number;
                }
                return false;
            });
        }
        console.log('Final hasPendingDeletion:', hasPendingDeletion);
    } catch (error) {
        console.error('Error checking pending requests:', error);
    }
    
    content.innerHTML = `
            <!-- Personal Information Section -->
            <div class="col-span-3 mb-6">
                <div class="bg-gray-50 border-2 border-gray-400 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        PERSONAL INFORMATION
                    </h3>
                    <div class="grid grid-cols-3 gap-6">
                        <!-- Row: ID Number and Full Name -->
                        <div>
                            <label class="block text-sm font-semibold mb-1">First Name</label>
                            <input type="text" id="first_name_${employee.id_number}" value="${employee.first_name}" readonly pattern="[A-Za-z\s]+" maxlength="20" title="Letters only, maximum 20 characters" class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field name-input">
                            <p id="first_name_error_${employee.id_number}" class="hidden text-sm text-red-600 mt-1">First name is required</p>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Last Name</label>
                            <input type="text" id="last_name_${employee.id_number}" value="${employee.last_name}" readonly pattern="[A-Za-z\s]+" maxlength="20" title="Letters only, maximum 20 characters" class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field name-input">
                            <p id="last_name_error_${employee.id_number}" class="hidden text-sm text-red-600 mt-1">Last name is required</p>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Middle Name <span class="text-gray-500 text-xs">(Optional)</span></label>
                            <input type="text" id="middle_name_${employee.id_number}" value="${employee.middle_name || ''}" readonly pattern="[A-Za-z\s]*" maxlength="20" title="Letters only, maximum 20 characters" class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field name-input">
                        </div>
                                                <div>
                            <label class="block text-sm font-semibold mb-1">Employee ID<span class="text-gray-500 text-xs">(Cannot be changed)</span></label>
                            <input type="text" value="${employee.id_number}" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-100 cursor-not-allowed employee-field-readonly" style="background-color:#f3f4f6;">
                        </div>
                        
                        <!-- Row: Position, Department, Email -->
                        <div>
                            <label class="block text-sm font-semibold mb-1">Position</label>
                            <input type="text" id="position_${employee.id_number}" value="${employee.position}" readonly pattern="[A-Za-z\s]+" maxlength="20" title="Letters only, maximum 20 characters" class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field name-input">
                            <p id="position_error_${employee.id_number}" class="hidden text-sm text-red-600 mt-1">Position is required</p>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Department</label>
                            <input type="text" id="department_${employee.id_number}" value="${employee.department}" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field">
                            <p id="department_error_${employee.id_number}" class="hidden text-sm text-red-600 mt-1">Department is required</p>
                        </div>

                         <div>
                            <label class="block text-sm font-semibold mb-1">Hire Date <span class="text-gray-500 text-xs">(Cannot be changed)</span></label>
                            <input type="date" id="hire_date_${employee.id_number}" value="${employee.hire_date}" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-100 cursor-not-allowed employee-field-readonly" style="background-color:#f3f4f6;">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Email</label>
                            <input type="email" id="email_${employee.id_number}" value="${employee.email || ''}" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$" title="Please enter a valid email address">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Phone</label>
                            <input type="tel" id="phone_${employee.id_number}" value="${employee.phone || ''}" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field" placeholder="+63 9XX-XXX-XXXX" title="Please enter Philippine mobile number (e.g., +63 912-345-6789)">
                        </div>
                        
                        <!-- Complete Address (full width) -->
                        <div class="col-span-3">
                            <label class="block text-sm font-semibold mb-1">Complete Address</label>
                            <textarea id="address_${employee.id_number}" rows="3" readonly minlength="20" maxlength="500" class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field">${employee.address || ''}</textarea>
                            <p id="address_error_${employee.id_number}" class="hidden text-sm text-red-600 mt-1"></p>
                            <p class="text-xs text-gray-500 mt-1">Minimum 20 characters. Include street, barangay, city/municipality, and province.</p>
                        </div>
                        
                        ${employee.account_role === 'teacher' ? `
                        <div>
                            <label class="block text-sm font-semibold mb-1">RFID</label>
                            <input type="text" id="rfid_uid" name="rfid_uid" autocomplete="off" class="w-full border border-gray-300 px-3 py-2 rounded-lg focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62] digits-only" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" data-maxlen="10" title="Please enter exactly 10 digits">
                        </div>
                        ` : ''}
                    </div>
                </div>
            </div>
            ${employee.username ? `
            <!-- Personal Account Section -->
            <div class="col-span-3 mb-6">
                <div class="bg-gray-50 border-2 border-gray-400 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                        <span>PERSONAL ACCOUNT</span>
                        <button type="button" onclick="showDeleteConfirmation('${employee.id_number}')" class="ml-auto px-3 py-1.5 text-sm bg-amber-600 text-white rounded hover:bg-amber-700">
                            Remove Login Access
                        </button>
                    </h3>
                    <p class="text-xs text-gray-500 mb-4 text-right">Removes login access only. The employee record will remain.</p>
                    <div class="space-y-4">
                        <div class="grid grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-semibold mb-1">Username <span class="text-gray-500 text-xs">(Auto-updates with last name)</span></label>
                                <input type="text" id="username_${employee.id_number}" value="${employee.username}" readonly class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-100 cursor-not-allowed employee-field-readonly" style="background-color:#f3f4f6;">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-1">Role</label>
                                <select id="role_${employee.id_number}" disabled class="w-full border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 employee-field">
                                    <option value="registrar" ${employee.account_role === 'registrar' ? 'selected' : ''}>Registrar</option>
                                    <option value="cashier" ${employee.account_role === 'cashier' ? 'selected' : ''}>Cashier</option>
                                    <option value="guidance" ${employee.account_role === 'guidance' ? 'selected' : ''}>Guidance</option>
                                    <option value="attendance" ${employee.account_role === 'attendance' ? 'selected' : ''}>Attendance</option>
                                    <option value="teacher" ${employee.account_role === 'teacher' ? 'selected' : ''}>Teacher</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-1">Password</label>
                            <div class="flex gap-2">
                                <input type="text" id="password_${employee.id_number}" placeholder="Click Reset Password button to generate" readonly disabled class="flex-1 border border-gray-300 px-3 py-2 rounded-lg bg-gray-50 cursor-not-allowed" style="pointer-events: none;">
                                <button type="button" id="resetPasswordBtn_${employee.id_number}" onclick="resetEmployeePassword('${employee.id_number}', '${employee.last_name}')" disabled class="px-4 py-2 bg-gray-400 text-white rounded-lg font-medium transition-colors cursor-not-allowed whitespace-nowrap">
                                    Reset Password
                                </button>
                            </div>
                            <small class="text-gray-500">Leave blank to keep current password. Click "Reset Password" to generate a new temporary password.</small>
                        </div>
                    </div>
                </div>
            </div>
            ` : `
            <!-- No Account Section -->
            <div class="col-span-3">
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200 text-center">
                    <p class="text-gray-600 mb-3">This employee doesn't have a system account.</p>
                    <button onclick="createAccountForEmployee('${employee.id_number}')" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600">
                        + Create Account
                    </button>
                </div>
            </div>
            `}
            
            <!-- Submit Buttons -->
            <div class="col-span-3 flex justify-end gap-4 pt-6 border-t border-gray-200">
                <button type="button" onclick="closeViewModal()" class="px-5 py-2 border border-blue-600 text-blue-900 rounded-xl hover:bg-[#0B2C62] hover:text-white transition">Back to List</button>
                <button type="button" id="saveChangesBtn_${employee.id_number}" onclick="saveEmployeeChanges()" class="px-5 py-2 bg-green-600 text-white rounded-xl shadow hover:bg-green-700 transition hidden">
                    Save Changes
                </button>
            </div>
        </div>
    `;
    
    // Show the modal first
    document.getElementById('viewEmployeeModal').classList.remove('hidden');
    
    // Update the delete button based on pending status AFTER modal is shown
    const deleteBtn = document.getElementById('deleteEmployeeBtn');
    if (deleteBtn) {
        if (hasPendingDeletion) {
            // Show Cancel Deletion Request button (orange)
            deleteBtn.textContent = 'Cancel Deletion Request';
            deleteBtn.className = 'px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition';
            deleteBtn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                showCancelRequestModal(employee.id_number);
            };
        } else {
            // Show normal Delete Employee button
            deleteBtn.textContent = 'Delete Employee';
            deleteBtn.className = 'px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition';
            deleteBtn.onclick = () => showDeleteEmployeeConfirmation(employee.id_number);
        }
        deleteBtn.classList.remove('hidden');
    }
    
    // Update edit button based on pending status AFTER modal is shown
    const editBtn = document.getElementById('editEmployeeBtn');
    if (editBtn) {
        if (hasPendingDeletion) {
            // Hide Edit button when there's a pending deletion
            editBtn.classList.add('hidden');
        } else {
            // Show Edit button normally
            editBtn.classList.remove('hidden');
            editBtn.textContent = 'Edit';
            editBtn.className = 'px-4 py-2 bg-[#2F8D46] text-white rounded-lg hover:bg-[#256f37] transition';
        }
    }
    
    // Setup input restrictions for dynamically created fields
    setTimeout(() => {
        setupInputRestrictions();
        setupUsernameAutoUpdate(employee.id_number);
        
        // Format phone number on load
        const phoneField = document.getElementById(`phone_${employee.id_number}`);
        if (phoneField && phoneField.value) {
            formatPhilippinePhone(phoneField);
        }
    }, 100);
}

// Auto-update username when last name changes in edit mode
function setupUsernameAutoUpdate(employeeId) {
    const lastNameField = document.getElementById(`last_name_${employeeId}`);
    const usernameField = document.getElementById(`username_${employeeId}`);
    
    if (!lastNameField || !usernameField) return;
    
    // Store original username to extract the ID part
    const originalUsername = usernameField.value;
    
    // Extract the 3-digit ID from username (e.g., smith001muzon@employee.cci.edu.ph -> 001)
    const match = originalUsername.match(/(\d{3})muzon@employee\.cci\.edu\.ph$/);
    const idNumber = match ? match[1] : '000';
    
    // Update username when last name changes
    lastNameField.addEventListener('input', function() {
        const lastName = this.value.trim().toLowerCase();
        if (lastName) {
            const newUsername = lastName + idNumber + 'muzon@employee.cci.edu.ph';
            usernameField.value = newUsername;
        }
    });
}

// Close view modal
function closeViewModal() {
    document.getElementById('viewEmployeeModal').classList.add('hidden');
    // Reset edit mode when closing
    isEditMode = false;
    currentEmployeeId = null;
    
    // Reset all button states to view mode
    const editBtn = document.getElementById('editEmployeeBtn');
    const deleteBtn = document.getElementById('deleteEmployeeBtn');
    const saveBtn = document.getElementById('saveChangesBtn');
    const cancelBtn = document.getElementById('cancelEditBtn');
    
    // Show Edit and Delete buttons
    if (editBtn) {
        editBtn.classList.remove('hidden');
        editBtn.textContent = 'Edit';
        editBtn.className = 'px-4 py-2 bg-[#2F8D46] text-white rounded-lg hover:bg-[#256f37] transition';
    }
    if (deleteBtn) deleteBtn.classList.remove('hidden');
    
    // Hide Save and Cancel buttons
    if (saveBtn) saveBtn.classList.add('hidden');
    if (cancelBtn) cancelBtn.classList.add('hidden');
    
    // Disable all fields
    document.querySelectorAll('.employee-field').forEach(field => {
        if (field.type === 'text' || field.type === 'email' || field.type === 'date' || field.tagName === 'SELECT') {
            field.readOnly = true;
            field.disabled = true;
            field.classList.add('bg-gray-50');
            field.classList.remove('bg-white');
        }
    });
}

// Toggle edit mode
let isEditMode = false;
function toggleEditMode() {
    const editBtn = document.getElementById('editEmployeeBtn');
    const deleteBtn = document.getElementById('deleteEmployeeBtn');
    const saveBtn = document.getElementById('saveChangesBtn');
    const cancelBtn = document.getElementById('cancelEditBtn');
    const fields = document.querySelectorAll('.employee-field');
    const resetPasswordBtn = document.querySelector('[id^="resetPasswordBtn_"]');
    const passwordField = document.querySelector('[id^="password_"]');
    
    isEditMode = true;
    
    // Hide Edit and Delete buttons
    if (editBtn) editBtn.classList.add('hidden');
    if (deleteBtn) deleteBtn.classList.add('hidden');
    
    // Show Save and Cancel buttons
    if (saveBtn) saveBtn.classList.remove('hidden');
    if (cancelBtn) cancelBtn.classList.remove('hidden');
    
    // Enable reset password button
    if (resetPasswordBtn) {
        resetPasswordBtn.disabled = false;
        resetPasswordBtn.removeAttribute('disabled');
        resetPasswordBtn.className = 'px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap';
        resetPasswordBtn.style.backgroundColor = '#eab308';
        resetPasswordBtn.style.cursor = 'pointer';
    }
    
    // Keep password field ALWAYS disabled and readonly (only Reset button should fill it)
    if (passwordField) {
        passwordField.readOnly = true;
        passwordField.disabled = true;
        passwordField.setAttribute('readonly', 'readonly');
        passwordField.setAttribute('disabled', 'disabled');
        passwordField.style.pointerEvents = 'none';
        passwordField.classList.add('bg-gray-50');
        passwordField.classList.remove('bg-white');
    }
    
    // Enable fields for editing (except readonly fields like ID Number and password)
    fields.forEach(field => {
        // Skip fields that should never be editable
        if (field.classList.contains('employee-field-readonly')) {
            return;
        }
        
        // Skip password field - it's controlled by reset button only
        if (field.id && field.id.includes('password_')) {
            return;
        }
        
        if (['TEXTAREA'].includes(field.tagName) || ['text', 'email', 'date', 'tel'].includes(field.type)) {
            field.readOnly = false;
            field.classList.remove('bg-gray-50');
            field.classList.add('bg-white');
            field.classList.add('focus:ring-2', 'focus:ring-[#0B2C62]', 'focus:border-[#0B2C62]');
            
            // Add phone formatting for tel fields
            if (field.type === 'tel') {
                field.oninput = function() { formatPhilippinePhone(this); };
            }
        } else if (['radio', 'checkbox'].includes(field.type) || field.tagName === 'SELECT') {
            field.disabled = false;
            field.classList.remove('bg-gray-50');
            field.classList.add('bg-white');
        }
    });
    
    // Setup input restrictions after enabling fields
    setTimeout(() => {
        setupInputRestrictions();
    }, 100);
}

function cancelEdit() {
    const editBtn = document.getElementById('editEmployeeBtn');
    const deleteBtn = document.getElementById('deleteEmployeeBtn');
    const saveBtn = document.getElementById('saveChangesBtn');
    const cancelBtn = document.getElementById('cancelEditBtn');
    const resetPasswordBtn = document.querySelector('[id^="resetPasswordBtn_"]');
    const passwordField = document.querySelector('[id^="password_"]');
    
    isEditMode = false;
    
    // Show Edit and Delete buttons
    if (editBtn) editBtn.classList.remove('hidden');
    if (deleteBtn) deleteBtn.classList.remove('hidden');
    
    // Hide Save and Cancel buttons
    if (saveBtn) saveBtn.classList.add('hidden');
    if (cancelBtn) cancelBtn.classList.add('hidden');
    
    // Disable reset password button and clear password field
    if (resetPasswordBtn) {
        resetPasswordBtn.disabled = true;
        resetPasswordBtn.setAttribute('disabled', 'disabled');
        resetPasswordBtn.className = 'px-4 py-2 bg-gray-400 text-white rounded-lg font-medium transition-colors cursor-not-allowed whitespace-nowrap';
    }
    
    // Clear password field when canceling
    if (passwordField) {
        passwordField.value = '';
        passwordField.disabled = true;
        passwordField.setAttribute('disabled', 'disabled');
    }
    
    // Reload the modal to restore original values
    if (currentEmployeeId) {
        // Fetch fresh employee data from server
        fetch(`view_employee.php?id=${currentEmployeeId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showEmployeeDetailsModal(data.employee);
                }
            })
            .catch(error => {
                console.error('Error reloading employee data:', error);
            });
    }
}

// Reset employee password function
function resetEmployeePassword(employeeId, lastName) {
    const passwordField = document.getElementById(`password_${employeeId}`);
    
    if (!passwordField || !lastName || !employeeId) {
        alert('Error: Required fields not found. Please ensure last name and employee ID are available.');
        return;
    }
    
    // Get values
    const lastNameClean = lastName.toLowerCase().replace(/[^a-z]/g, '');
    
    // Extract the 3-digit number from employee ID (e.g., CCI2025-006 -> 006)
    const parts = employeeId.split('-');
    const idNumber = parts.length === 2 ? parts[1] : '000';
    
    // Get current year
    const currentYear = new Date().getFullYear();
    
    // Format: lastname + idNumber + currentYear (e.g., smith0062025)
    const newPassword = lastNameClean + idNumber + currentYear;
    
    // Enable field and set value (keep it enabled so it submits with the form)
    passwordField.disabled = false;
    passwordField.removeAttribute('disabled');
    passwordField.value = newPassword;
    // Keep readonly and pointer-events:none for visual purposes, but NOT disabled
    passwordField.readOnly = true;
    passwordField.style.pointerEvents = 'none';
    
    // Show custom modal
    showPasswordResetModal(newPassword);
}

// Show password reset modal
function showPasswordResetModal(password) {
    const modal = document.createElement('div');
    modal.id = 'passwordResetModal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center';
    modal.style.zIndex = '10100';
    modal.innerHTML = `
        <div class="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <div class="flex flex-col items-center text-center">
                <div class="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center mb-4">
                    <svg class="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <h3 class="text-xl font-semibold text-gray-900 mb-2">Temporary Password Generated</h3>
                <p class="text-gray-600 mb-4">The new temporary password has been generated:</p>
                <div class="bg-gray-100 border border-gray-300 rounded-lg px-4 py-3 mb-4 w-full">
                    <p class="text-lg font-mono font-semibold text-gray-900 break-all">${password}</p>
                </div>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                    <p class="text-sm text-blue-800"><strong>⚠️ Important:</strong> Please save this password and click <strong>"Save Changes"</strong> button to apply the password reset.</p>
                </div>
                <p class="text-xs text-amber-600 mb-6">The employee will be required to change this password on first login.</p>
                <button onclick="closePasswordResetModal()" class="w-full py-2.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 font-medium">
                    OK, I've Saved It
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

// Close password reset modal
function closePasswordResetModal() {
    const modal = document.getElementById('passwordResetModal');
    if (modal) {
        modal.remove();
    }
}

function saveEmployeeChanges() {
    if (!currentEmployeeId) {
        showToast('No employee selected', 'error');
        return;
    }
    
    // Collect employee data from the form fields
    const firstName = document.getElementById(`first_name_${currentEmployeeId}`)?.value;
    const middleName = document.getElementById(`middle_name_${currentEmployeeId}`)?.value;
    const lastName = document.getElementById(`last_name_${currentEmployeeId}`)?.value;
    const position = document.getElementById(`position_${currentEmployeeId}`)?.value;
    const department = document.getElementById(`department_${currentEmployeeId}`)?.value;
    const email = document.getElementById(`email_${currentEmployeeId}`)?.value;
    const phone = document.getElementById(`phone_${currentEmployeeId}`)?.value;
    const address = document.getElementById(`address_${currentEmployeeId}`)?.value;
    const hireDate = document.getElementById(`hire_date_${currentEmployeeId}`)?.value;
    
    // Clear all previous errors
    const fields = [
        { id: `first_name_${currentEmployeeId}`, errorId: `first_name_error_${currentEmployeeId}`, value: firstName },
        { id: `last_name_${currentEmployeeId}`, errorId: `last_name_error_${currentEmployeeId}`, value: lastName },
        { id: `position_${currentEmployeeId}`, errorId: `position_error_${currentEmployeeId}`, value: position },
        { id: `department_${currentEmployeeId}`, errorId: `department_error_${currentEmployeeId}`, value: department }
    ];
    
    let hasErrors = false;
    
    // Clear all red borders and error messages
    fields.forEach(field => {
        const element = document.getElementById(field.id);
        const errorElement = document.getElementById(field.errorId);
        if (element) {
            element.classList.remove('border-red-500');
            element.classList.add('border-gray-300');
        }
        if (errorElement) errorElement.classList.add('hidden');
    });
    
    // Clear address error
    const addressField = document.getElementById(`address_${currentEmployeeId}`);
    const addressError = document.getElementById(`address_error_${currentEmployeeId}`);
    if (addressError) addressError.classList.add('hidden');
    if (addressField) {
        addressField.classList.remove('border-red-500');
        addressField.classList.add('border-gray-300');
    }
    
    // Validate required fields
    fields.forEach(field => {
        if (!field.value || field.value.trim() === '') {
            const element = document.getElementById(field.id);
            const errorElement = document.getElementById(field.errorId);
            if (element) {
                element.classList.remove('border-gray-300');
                element.classList.add('border-red-500');
            }
            if (errorElement) errorElement.classList.remove('hidden');
            hasErrors = true;
        }
    });
    
    // Validate address
    let addressErrorMsg = '';
    if (!address || address.trim().length < 20) {
        addressErrorMsg = 'Complete address must include multiple components (street, barangay, city, etc.) separated by commas or spaces.';
        hasErrors = true;
    } else if (address.trim().length > 500) {
        addressErrorMsg = 'Complete address must not exceed 500 characters.';
        hasErrors = true;
    } else if (!/[,\s]/.test(address)) {
        addressErrorMsg = 'Complete address must include multiple components (street, barangay, city, etc.) separated by commas or spaces.';
        hasErrors = true;
    }
    
    if (addressErrorMsg) {
        if (addressError) {
            addressError.textContent = addressErrorMsg;
            addressError.classList.remove('hidden');
        }
        if (addressField) {
            addressField.classList.remove('border-gray-300');
            addressField.classList.add('border-red-500');
        }
    }
    
    if (hasErrors) {
        return;
    }
    
    // Prepare form data
    // Show confirmation dialog before saving
    showEmployeeSaveConfirmation(firstName, middleName, lastName, position, department, email, phone, address, hireDate);
}

function showEmployeeSaveConfirmation(firstName, middleName, lastName, position, department, email, phone, address, hireDate) {
    const c = document.createElement('div');
    c.className = 'fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-[2147483647]';
    c.innerHTML = `
        <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 p-6">
            <h3 class="text-lg font-semibold mb-2">Confirm Changes</h3>
            <p class="text-gray-600 mb-6">Are you sure you want to save these changes to the employee information?</p>
            <div class="flex justify-end gap-2">
                <button id="cCancel" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded">Cancel</button>
                <button id="cSave" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Confirm & Save</button>
            </div>
        </div>
    `;
    document.body.appendChild(c);
    c.querySelector('#cCancel').onclick = () => c.remove();
    c.querySelector('#cSave').onclick = () => {
        c.remove();
        performEmployeeSave(firstName, middleName, lastName, position, department, email, phone, address, hireDate);
    };
}

function performEmployeeSave(firstName, middleName, lastName, position, department, email, phone, address, hireDate) {
    const password = document.getElementById(`password_${currentEmployeeId}`)?.value;
    
    const formData = new FormData();
    formData.append('employee_id', currentEmployeeId);
    formData.append('first_name', firstName);
    formData.append('middle_name', middleName || '');
    formData.append('last_name', lastName);
    formData.append('position', position);
    formData.append('department', department);
    formData.append('email', email || '');
    formData.append('phone', phone || '');
    formData.append('address', address);
    formData.append('hire_date', hireDate);
    if (password) {
        formData.append('password', password);
    }
    
    fetch('edit_employee.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Show success notification
            showToast('Employee updated successfully!', 'success');
            
            // Exit edit mode and refresh the modal data without closing
            isEditMode = false;
            
            // Show Edit and Delete buttons
            const editBtn = document.getElementById('editEmployeeBtn');
            const deleteBtn = document.getElementById('deleteEmployeeBtn');
            if (editBtn) editBtn.classList.remove('hidden');
            if (deleteBtn) deleteBtn.classList.remove('hidden');
            
            // Hide Save and Cancel buttons
            const saveBtn = document.getElementById('saveChangesBtn');
            const cancelBtn = document.getElementById('cancelEditBtn');
            if (saveBtn) saveBtn.classList.add('hidden');
            if (cancelBtn) cancelBtn.classList.add('hidden');
            
            // Reload employee data in the modal without closing it
            fetch(`view_employee.php?id=${currentEmployeeId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showEmployeeDetailsModal(data.employee);
                    }
                });
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error updating employee: ' + error.message, 'error');
    });
}

// Get current employee ID
function getCurrentEmployeeId() {
    return currentEmployeeId;
}

// Show delete confirmation modal
function showDeleteConfirmation(employeeId) {
    const modal = document.getElementById('deleteConfirmationModal');
    modal.classList.remove('hidden');
    const confirmBtn = document.getElementById('confirmDeleteBtn');
    confirmBtn.onclick = function() {
        removeAccount(employeeId);
    };
}

function closeDeleteConfirmation() {
    document.getElementById('deleteConfirmationModal').classList.add('hidden');
}

// Delete Employee (entire record) - Request approval from Owner
function showDeleteEmployeeConfirmation(employeeId) {
    // Don't close the view modal - keep it in the background
    
    // Create modern delete confirmation modal with reason input
    const modal = document.createElement('div');
    modal.id = 'deleteConfirmModal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-[9999] flex items-center justify-center p-4';
    modal.style.pointerEvents = 'auto';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-scale-in';
    modalContent.style.pointerEvents = 'auto';
    modalContent.style.position = 'relative';
    modalContent.style.zIndex = '10000';
    // Store employeeId in a global variable for the inline handlers
    window._deleteEmployeeId = employeeId;
    window._deleteModal = modal;
    
    modalContent.innerHTML = `
        <div class="p-8">
            <div class="mx-auto w-20 h-20 bg-orange-50 rounded-full flex items-center justify-center mb-6">
                <svg class="w-10 h-10 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
            </div>
            <h3 class="text-2xl font-bold text-gray-900 mb-3 text-center">Request Employee Deletion</h3>
            <p class="text-gray-600 mb-4 text-center leading-relaxed">
                This action requires Owner approval. Please provide a reason for deletion.
            </p>
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">Deletion Reason *</label>
                <textarea 
                    id="deletionReasonInput"
                    rows="4"
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                    placeholder="Enter reason for deleting this employee..."
                    required
                ></textarea>
                <p class="text-xs text-gray-500 mt-1">This will be sent to the Owner for approval</p>
            </div>
        </div>
        <div class="px-8 pb-8 flex gap-3">
            <button 
                onclick="window._deleteModal.remove(); return false;"
                class="flex-1 px-6 py-3.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-xl font-semibold transition-all duration-200"
                type="button"
            >
                Cancel
            </button>
            <button 
                onclick="handleDeleteConfirm(); return false;"
                class="flex-1 px-6 py-3.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-semibold transition-all duration-200"
                type="button"
                id="confirmDeleteBtn"
            >
                Send Request
            </button>
        </div>
    `;
    
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    // Add animation style if not present
    if (!document.getElementById('modal-animations')) {
        const style = document.createElement('style');
        style.id = 'modal-animations';
        style.textContent = `
            @keyframes scale-in {
                from { opacity: 0; transform: scale(0.9); }
                to { opacity: 1; transform: scale(1); }
            }
            .animate-scale-in { animation: scale-in 0.2s ease-out; }
        `;
        document.head.appendChild(style);
    }
}

// Handle delete confirmation (called from inline onclick)
async function handleDeleteConfirm() {
    const employeeId = window._deleteEmployeeId;
    const modal = window._deleteModal;
    const deletionReason = document.getElementById('deletionReasonInput').value.trim();
    
    if (!deletionReason) {
        showToast('Please provide a reason for deletion', 'error');
        return;
    }
    
    // Disable button and show loading
    const confirmBtn = document.getElementById('confirmDeleteBtn');
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<svg class="animate-spin h-5 w-5 mx-auto" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>';
    
    try {
        const formData = new FormData();
        formData.append('action', 'request_hr_deletion');
        formData.append('employee_id', employeeId);
        formData.append('deletion_reason', deletionReason);
        
        console.log('Sending deletion request for employee:', employeeId);
        console.log('Deletion reason:', deletionReason);
        
        const response = await fetch('../AdminF/request_hr_employee_deletion.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        console.log('Deletion request response:', data);
        
        if (data.success) {
            modal.remove();
            showToast('✅ Deletion request sent to Owner for approval', 'success');
            
            // Close the employee information modal
            closeViewModal();
            
            // Update the row to show pending status without refresh
            updateRowPendingStatus(employeeId, true);
            
            // Refresh the page to show the pending status
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            showToast('Error: ' + data.message, 'error');
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = 'Send Request';
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('An error occurred while sending the request', 'error');
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = 'Send Request';
    }
}

function closeDeleteEmployeeConfirmation() {
    const modal = document.getElementById('deleteEmployeeModal');
    if (modal) modal.classList.add('hidden');
}

// Show cancel deletion request modal (matching Registrar style)
function showCancelRequestModal(employeeId) {
    const modal = document.createElement('div');
    modal.id = 'cancelRequestModal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[99999]';
    modal.innerHTML = `
        <div class="bg-white rounded-2xl p-6 max-w-md w-full mx-4">
            <div class="flex flex-col items-center text-center">
                <div class="w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center mb-3">
                    <svg class="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Cancel Deletion Request?</h3>
                <p class="text-gray-600">Are you sure you want to cancel the pending deletion request for this employee?</p>
            </div>
            <div class="flex gap-3 mt-6">
                <button onclick="document.getElementById('cancelRequestModal').remove()" class="flex-1 px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-medium transition">
                    No, Keep Request
                </button>
                <button onclick="confirmCancelEmployeeRequest('${employeeId}')" class="flex-1 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition">
                    Yes, Cancel Request
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

// Confirm cancel deletion request (matching Registrar logic)
async function confirmCancelEmployeeRequest(employeeId) {
    try {
        const response = await fetch('../AdminF/cancel_hr_deletion_request.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=cancel_deletion_request&employee_id=${encodeURIComponent(employeeId)}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('✅ Deletion request cancelled successfully', 'success');
            
            // Remove the modal
            const modal = document.getElementById('cancelRequestModal');
            if (modal) modal.remove();
            
            // Close the employee view modal
            closeViewModal();
            
            // Remove pending status from the row
            updateRowPendingStatus(employeeId, false);
        } else {
            showToast('Error: ' + (data.message || 'Failed to cancel request'), 'error');
        }
    } catch (error) {
        console.error('Error cancelling request:', error);
        showToast('An error occurred while cancelling the request', 'error');
    }
}



// Update row pending status dynamically
function updateRowPendingStatus(employeeId, isPending) {
    const table = document.querySelector('table tbody');
    if (!table) return;
    
    const rows = table.querySelectorAll('tr');
    rows.forEach(row => {
        const idCell = row.querySelector('td:first-child');
        if (!idCell) return;
        
        const idText = idCell.textContent.trim();
        if (idText.includes(employeeId)) {
            if (isPending) {
                // Add pending status
                row.classList.add('bg-orange-50', 'border-l-4', 'border-orange-500');
                
                // Add badge if not exists
                if (!idCell.querySelector('.bg-orange-100')) {
                    const badge = document.createElement('span');
                    badge.className = 'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-orange-100 text-orange-800 ml-2';
                    badge.innerHTML = `
                        <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/>
                        </svg>
                        Pending Deletion
                    `;
                    idCell.appendChild(badge);
                }
            } else {
                // Remove pending status
                row.classList.remove('bg-orange-50', 'border-l-4', 'border-orange-500');
                
                // Remove badge
                const badge = idCell.querySelector('.bg-orange-100');
                if (badge) {
                    badge.remove();
                }
            }
        }
    });
}

// Account management functions
function editAccountDetails(employeeId) {
    fetch(`view_employee.php?id=${employeeId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.employee.username) {
                showEditAccountModal(data.employee);
            } else {
                showToast('Error loading account details', 'error');
            }
        });
}

function resetPassword(employeeId) {
    if (confirm('Are you sure you want to reset this employee\'s password?')) {
        const newPassword = prompt('Enter new password:');
        if (newPassword && newPassword.length >= 6) {
            fetch('manage_account.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=reset_password&employee_id=${employeeId}&new_password=${encodeURIComponent(newPassword)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Password reset successfully', 'success');
                    setTimeout(() => closeViewModal(), 1500);
                } else {
                    showToast('Error: ' + data.message, 'error');
                }
            });
        } else {
            showToast('Password must be at least 6 characters long', 'error');
        }
    }
}

function removeAccount(employeeId) {
    // Perform deletion and use custom toast, no browser confirm() or alert()
    fetch('manage_account.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=remove_account&employee_id=${employeeId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeDeleteConfirmation();
            closeViewModal();
            showToast('Account removed successfully', 'success');
            setTimeout(() => location.reload(), 800);
        } else {
            closeDeleteConfirmation();
            showToast(data.message || 'Error removing account', 'error');
        }
    })
    .catch(() => {
        closeDeleteConfirmation();
        showToast('Network error while removing account', 'error');
    });
}

function createAccountForEmployee(employeeId) {
    fetch(`view_employee.php?id=${employeeId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showCreateAccountModal(data.employee);
            }
        });
}

// Modal functions for account management
function showEditAccountModal(employee) {
    const content = document.getElementById('editAccountContent');
    content.innerHTML = `
        <input type="hidden" name="employee_id" value="${employee.id_number}">
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <input type="text" name="username" value="${employee.username}" required 
                   class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
            <select name="role" required class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="registrar" ${employee.account_role === 'registrar' ? 'selected' : ''}>Registrar</option>
                <option value="cashier" ${employee.account_role === 'cashier' ? 'selected' : ''}>Cashier</option>
                <option value="guidance" ${employee.account_role === 'guidance' ? 'selected' : ''}>Guidance</option>
                <option value="attendance" ${employee.account_role === 'attendance' ? 'selected' : ''}>Attendance</option>
                <option value="teacher" ${employee.account_role === 'teacher' ? 'selected' : ''}>Teacher</option>
                <option value="department_head" ${employee.account_role === 'department_head' ? 'selected' : ''}>Department Head</option>
            </select>
        </div>
    `;
    document.getElementById('editAccountModal').classList.remove('hidden');
}

function showCreateAccountModal(employee) {
    const content = document.getElementById('createAccountContent');
    content.innerHTML = `
        <input type="hidden" name="employee_id" value="${employee.id_number}">
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <input type="text" id="ca_username" name="username" required autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" tabindex="0"
                   class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500">
            <span id="ca_username_error" class="hidden text-red-500 text-sm mt-1"></span>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <input type="password" name="password" required minlength="6" autocomplete="new-password" tabindex="0"
                   class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
            <select name="role" id="ca_role" required onchange="toggleCreateAccountRFID()" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500" tabindex="0">
                <option value="">Select Role</option>
                <option value="registrar">Registrar</option>
                <option value="cashier">Cashier</option>
                <option value="guidance">Guidance</option>
                <option value="attendance">Attendance</option>
                <option value="teacher">Teacher</option>
                <option value="department_head">Department Head</option>
            </select>
        </div>
        <div id="ca_rfid_container" class="mb-4 hidden">
            <label class="block text-sm font-medium text-gray-700 mb-2">RFID Number *</label>
            <input type="text" id="ca_rfid_uid" name="rfid_uid" autocomplete="off" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-green-500 digits-only" inputmode="numeric" pattern="[0-9]{10}" minlength="10" maxlength="10" title="Please enter exactly 10 digits (numbers only)" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10)">
        </div>
    `;
    document.getElementById('createAccountModal').classList.remove('hidden');
    // Autofocus the username field to ensure typing works immediately
    setTimeout(() => {
        const usernameInput = document.querySelector('#createAccountModal input[name="username"]');
        if (usernameInput) {
            usernameInput.readOnly = false;
            usernameInput.disabled = false;
            usernameInput.focus();
        }
        const passwordInput = document.querySelector('#createAccountModal input[name="password"]');
        if (passwordInput) {
            passwordInput.readOnly = false;
            passwordInput.disabled = false;
        }
    }, 0);
    // Prevent global key handlers from hijacking keystrokes while modal is open
    const modalEl = document.getElementById('createAccountModal');
    if (modalEl && !modalEl._keydownBound) {
        modalEl.addEventListener('keydown', (e) => { e.stopPropagation(); }, true);
        modalEl._keydownBound = true;
    }
}

function closeEditAccountModal() {
    document.getElementById('editAccountModal').classList.add('hidden');
}

function closeCreateAccountModal() {
    document.getElementById('createAccountModal').classList.add('hidden');
}

function updateAccount(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    formData.append('action', 'update_account');
    
    fetch('manage_account.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Account updated successfully', 'success');
            closeEditAccountModal();
            closeViewModal();
            setTimeout(() => location.reload(), 1500);
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    });
}

function createNewAccount(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    formData.append('create_account', '1');
    // Clear previous username error styles/messages
    const u = document.getElementById('ca_username');
    const uErr = document.getElementById('ca_username_error');
    if (u) {
        u.classList.remove('border-red-500','ring-2','ring-red-500');
    }
    if (uErr) {
        uErr.textContent = '';
        uErr.classList.add('hidden');
    }
    
    fetch('create_account.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Account created successfully', 'success');
            closeCreateAccountModal();
            closeViewModal();
            setTimeout(() => location.reload(), 1500);
        } else {
            // Inline handle for duplicate username
            if (data.message && data.message.toLowerCase().includes('username already taken')) {
                if (u) {
                    u.classList.add('border-red-500','ring-2','ring-red-500');
                    u.focus();
                }
                if (uErr) {
                    uErr.textContent = 'Username already in use';
                    uErr.classList.remove('hidden');
                }
                return; // keep modal open, no toast
            }
            showToast('Error: ' + data.message, 'error');
        }
    });
}

// Edit employee function
function editEmployee(employeeId) {
    fetch(`view_employee.php?id=${employeeId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showEditEmployeeModal(data.employee);
            } else {
                showToast('Error loading employee details: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('Error loading employee details', 'error');
        });
}

// Show edit employee modal
function showEditEmployeeModal(employee) {
    const content = document.getElementById('editEmployeeContent');
    content.innerHTML = `
        <input type="hidden" name="employee_id" value="${employee.id_number}">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">ID Number</label>
                <input type="text" name="id_number" value="${employee.id_number}" readonly class="w-full border border-gray-300 rounded-lg px-3 py-2 bg-gray-100 cursor-not-allowed" style="background-color:#f3f4f6;">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input type="text" name="full_name" value="${employee.full_name}" required class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Position</label>
                <input type="text" name="position" value="${employee.position}" required class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Department</label>
                <select name="department" required class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
                    <option value="Academic Affairs" ${employee.department === 'Academic Affairs' ? 'selected' : ''}>Academic Affairs</option>
                    <option value="Student Affairs" ${employee.department === 'Student Affairs' ? 'selected' : ''}>Student Affairs</option>
                    <option value="Finance" ${employee.department === 'Finance' ? 'selected' : ''}>Finance</option>
                    <option value="Human Resources" ${employee.department === 'Human Resources' ? 'selected' : ''}>Human Resources</option>
                    <option value="IT Department" ${employee.department === 'IT Department' ? 'selected' : ''}>IT Department</option>
                    <option value="Maintenance" ${employee.department === 'Maintenance' ? 'selected' : ''}>Maintenance</option>
                    <option value="Security" ${employee.department === 'Security' ? 'selected' : ''}>Security</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input type="email" name="email" value="${employee.email || ''}" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                <input type="text" name="phone" value="${employee.phone || ''}" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#0B2C62] focus:border-[#0B2C62]">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Hire Date <span class="text-gray-500 text-xs">(Cannot be changed)</span></label>
                <input type="date" name="hire_date" value="${employee.hire_date}" readonly class="w-full border border-gray-300 rounded-lg px-3 py-2 bg-gray-100 cursor-not-allowed" style="background-color:#f3f4f6;">
            </div>
        </div>
    `;
    document.getElementById('editEmployeeModal').classList.remove('hidden');
}

// Close edit modal
function closeEditModal() {
    document.getElementById('editEmployeeModal').classList.add('hidden');
}

// Handle edit employee form submission
document.getElementById('editEmployeeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('edit_employee.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success notification
            showToast('Employee updated successfully!', 'success');
            
            closeEditModal();
            // Reload employee data in the view modal without closing it
            fetch(`view_employee.php?id=${currentEmployeeId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showEmployeeDetailsModal(data.employee);
                    }
                });
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error updating employee', 'error');
    });
});

// Removed duplicate create account form submission handler to avoid duplicate alerts.

// Show success notification with animation
const notificationElement = document.getElementById("notif");
if (notificationElement) {
    setTimeout(() => {
        notificationElement.style.transform = 'translateX(0)';
        notificationElement.style.opacity = '1';
    }, 100);
    
    setTimeout(() => {
        notificationElement.style.opacity = '0';
        notificationElement.style.transform = 'translateX(100px)';
        setTimeout(() => notificationElement.remove(), 300);
    }, 4000);
}

// Search and pagination functionality (10 per page)
const searchInput = document.getElementById('searchInput');
const tableBody = document.getElementById('employeeTable');
const prevBtn = document.getElementById('prevPage');
const nextBtn = document.getElementById('nextPage');
const pageInfo = document.getElementById('pageInfo');
const pageSize = 10;
let currentPage = 1;
let allRows = Array.from(tableBody.querySelectorAll('tr'));

function renderPage() {
    // Filter rows based on search
    const searchTerm = searchInput.value.toLowerCase();
    const filteredRows = allRows.filter(row => {
        const text = row.textContent.toLowerCase();
        return text.includes(searchTerm);
    });
    
    // Calculate pagination
    const total = filteredRows.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    currentPage = Math.min(Math.max(1, currentPage), totalPages);
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    const pageRows = filteredRows.slice(start, end);
    
    // Hide all rows first
    allRows.forEach(row => row.style.display = 'none');
    
    // Show only current page rows
    pageRows.forEach(row => row.style.display = '');
    
    // Update pagination controls
    if (pageInfo) pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    if (prevBtn) prevBtn.disabled = (currentPage <= 1);
    if (nextBtn) nextBtn.disabled = (currentPage >= totalPages);
}

// Event listeners
if (searchInput) {
    searchInput.addEventListener('input', () => {
        currentPage = 1;
        renderPage();
    });
}
if (prevBtn) prevBtn.addEventListener('click', () => { currentPage--; renderPage(); });
if (nextBtn) nextBtn.addEventListener('click', () => { currentPage++; renderPage(); });

// Initial render
renderPage();

// Menu dropdown functionality
document.getElementById('menuBtn').addEventListener('click', function() {
    const dropdown = document.getElementById('dropdownMenu');
    dropdown.classList.toggle('hidden');
});

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('dropdownMenu');
    const menuButton = document.getElementById('menuBtn');
    
    if (!dropdown.contains(event.target) && !menuButton.contains(event.target)) {
        dropdown.classList.add('hidden');
    }
});

// =========================
// Add Employee Confirmation (mirrors Super Admin)
// =========================
function confirmAddEmployee() {
    const modal = document.getElementById('addEmployeeModal');
    if (!modal) return;

    const form = modal.querySelector('form');
    if (!form) return;

    // Clear previous error states and messages
    clearFieldErrors(form);

    // Gather values
    const idNumber = (form.querySelector('input[name="id_number"]')?.value || '').trim();
    const firstName = (form.querySelector('input[name="first_name"]')?.value || '').trim();
    const middleName = (form.querySelector('input[name="middle_name"]')?.value || '').trim();
    const lastName = (form.querySelector('input[name="last_name"]')?.value || '').trim();
    const position = (form.querySelector('input[name="position"]')?.value || '').trim();
    const department = (form.querySelector('select[name="department"]')?.value || '').trim();
    const hireDate = (form.querySelector('input[name="hire_date"]')?.value || '').trim();
    const email = (form.querySelector('input[name="email"]')?.value || '').trim();
    const phone = (form.querySelector('input[name="phone"]')?.value || '').trim();
    const address = (form.querySelector('textarea[name="address"]')?.value || '').trim();
    const createAccount = !!form.querySelector('#createAccount')?.checked;
    const username = (form.querySelector('input[name="username"]')?.value || '').trim();
    const password = (form.querySelector('input[name="password"]')?.value || '');
    const role = (form.querySelector('#employeeRole')?.value || '').trim();
    const rfid = (form.querySelector('#rfid_uid')?.value || '').trim();

    // Validate with inline messages
    let hasErrors = false;
    const need = (selector, msg) => { const el = form.querySelector(selector); if (!el || !el.value.trim()) { highlightFieldError(el, msg); hasErrors = true; return false; } return true; };
    const invalid = (selector, testFn, msg) => { const el = form.querySelector(selector); const val = el?.value?.trim() || ''; if (val && !testFn(val)) { highlightFieldError(el, msg); hasErrors = true; } };

    // Employee ID is auto-generated, no need to validate
    need('input[name="first_name"]', 'First name is required');
    need('input[name="last_name"]', 'Last name is required');
    need('input[name="position"]', 'Position is required');
    need('select[name="department"]', 'Department is required');
    need('input[name="hire_date"]', 'Hire date is required');
    
    // Validate hire date is not in the future
    if (hireDate) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const selectedDate = new Date(hireDate + 'T00:00:00');
        if (selectedDate > today) {
            highlightFieldError(form.querySelector('input[name="hire_date"]'), 'Hire date cannot be in the future');
            hasErrors = true;
        }
    }
    
    // Email validation - only allow trusted email providers
    if (need('input[name="email"]', 'Email is required')) {
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const allowedDomains = [
            'gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 
            'icloud.com', 'protonmail.com', 'aol.com', 'zoho.com',
            'mail.com', 'yandex.com', 'gmx.com', 'tutanota.com'
        ];
        
        if (!emailPattern.test(email)) {
            highlightFieldError(form.querySelector('input[name="email"]'), 'Please enter a valid email address');
            hasErrors = true;
        } else {
            const domain = email.split('@')[1].toLowerCase();
            if (!allowedDomains.includes(domain)) {
                highlightFieldError(form.querySelector('input[name="email"]'), 'Please use a valid email provider (Gmail, Yahoo, Outlook, etc.)');
                hasErrors = true;
            }
        }
    }
    
    // Phone validation (accept formatted: +63 9XX-XXX-XXXX)
    if (need('input[name="phone"]', 'Phone is required')) {
        const phoneDigits = phone.replace(/\D/g, '');
        if (!phone.startsWith('+63')) {
            highlightFieldError(form.querySelector('input[name="phone"]'), 'Phone must start with +63');
            hasErrors = true;
        }
        if (phoneDigits.length !== 12) { // 63 + 10 digits
            highlightFieldError(form.querySelector('input[name="phone"]'), 'Phone must be in format +63 9XX-XXX-XXXX');
            hasErrors = true;
        }
        if (!phoneDigits.startsWith('639')) {
            highlightFieldError(form.querySelector('input[name="phone"]'), 'Philippine mobile numbers start with 9 after +63');
            hasErrors = true;
        }
    }
    
    // Address validation
    if (!address) {
        highlightFieldError(form.querySelector('textarea[name="address"]'), 'Address is required');
        hasErrors = true;
    } else if (address.length < 20) {
        highlightFieldError(form.querySelector('textarea[name="address"]'), 'Complete address must be at least 20 characters long');
        hasErrors = true;
    } else if (address.length > 500) {
        highlightFieldError(form.querySelector('textarea[name="address"]'), 'Complete address must not exceed 500 characters');
        hasErrors = true;
    } else {
        // Count commas to ensure multiple address components
        const commaCount = (address.match(/,/g) || []).length;
        if (commaCount < 3) {
            highlightFieldError(form.querySelector('textarea[name="address"]'), 'Complete address must include at least 4 components separated by commas (e.g., Street, Barangay, City, Province)');
            hasErrors = true;
        }
        // Check if address has meaningful content (not just commas)
        const addressParts = address.split(',').map(part => part.trim()).filter(part => part.length > 0);
        if (addressParts.length < 4) {
            highlightFieldError(form.querySelector('textarea[name="address"]'), 'Complete address must include street, barangay, city/municipality, and province');
            hasErrors = true;
        }
    }

    if (createAccount) {
        // Username and password are auto-generated, no need to validate
        if (!role) { highlightFieldError(form.querySelector('#employeeRole'), 'Role is required'); hasErrors = true; }
        if (role === 'teacher') {
            const r = form.querySelector('#rfid_uid');
            if (!r || !/^\d{10}$/.test((r.value || '').trim())) { highlightFieldError(r, 'RFID must be exactly 10 digits'); hasErrors = true; }
        }
    }
    if (hasErrors) return;

    const fullName = `${firstName}${middleName ? ' ' + middleName : ''} ${lastName}`;
    const formattedDate = hireDate ? new Date(hireDate + 'T00:00:00').toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : 'N/A';

    showHRConfirmationModal({ idNumber, fullName, position, department, email, phone, address, hireDate: formattedDate, createAccount, username, password, role, rfid, form });
}

function showHRConfirmationModal(data) {
    const existing = document.getElementById('hr-confirm-modal');
    if (existing) existing.remove();

    const wrapper = document.createElement('div');
    wrapper.id = 'hr-confirm-modal';
    wrapper.className = 'fixed inset-0 bg-black bg-opacity-70 z-[6000] flex items-center justify-center p-4';
    wrapper.innerHTML = `
    <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden border-2 border-gray-200">
      <div class="bg-gradient-to-r from-[#0B2C62] to-[#153e86] text-white px-6 py-5 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <h3 class="text-xl font-bold">Confirm Employee Creation</h3>
        </div>
        <button onclick="closeHRConfirmationModal()" class="text-white hover:text-gray-200 p-2 rounded-lg hover:bg-white/10 transition-colors">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="p-6 max-h-[calc(90vh-160px)] overflow-y-auto bg-gray-50">
        <div class="mb-6">
          <div class="flex items-center gap-3 mb-4 p-3 bg-[#0B2C62]/5 rounded-lg">
            <div class="w-8 h-8 bg-[#0B2C62] rounded-lg flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            </div>
            <h4 class="text-lg font-bold text-[#0B2C62]">Personal Information</h4>
          </div>
          <div class="bg-white rounded-lg p-5 shadow-sm border border-gray-200 space-y-3">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Employee ID:</span><span class="text-[#0B2C62] font-medium text-lg">${escapeHtml(data.idNumber)}</span></div>
              <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Full Name:</span><span class="text-[#0B2C62] font-medium text-lg">${escapeHtml(data.fullName)}</span></div>
              <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Position:</span><span class="text-gray-900 font-medium">${escapeHtml(data.position)}</span></div>
              <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Department:</span><span class="text-gray-900 font-medium">${escapeHtml(data.department)}</span></div>
              <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Email:</span><span class="text-gray-900 font-medium">${escapeHtml(data.email)}</span></div>
              <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Phone:</span><span class="text-gray-900 font-medium">${escapeHtml(data.phone)}</span></div>
            </div>
            <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Address:</span><span class="text-gray-900 font-medium">${escapeHtml(data.address)}</span></div>
            <div class="p-3 bg-gray-50 rounded-lg"><span class="font-semibold text-gray-800 block">Hire Date:</span><span class="text-gray-900 font-medium">${escapeHtml(data.hireDate)}</span></div>
          </div>
        </div>
        <div class="mb-6">
          <div class="flex items-center gap-3 mb-4 p-3 bg-[#0B2C62]/5 rounded-lg">
            <div class="w-8 h-8 bg-[#0B2C62] rounded-lg flex items-center justify-center">
              <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
            </div>
            <h4 class="text-lg font-bold text-[#0B2C62]">System Account</h4>
          </div>
          <div class="bg-white rounded-lg p-5 shadow-sm border-2 border-gray-300 space-y-4">
            ${data.createAccount ? `
              <div class="flex items-center gap-3 mb-4"><svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg><span class="font-semibold text-gray-900">System account will be created</span></div>
              <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div><span class="font-semibold text-gray-700 block">Username:</span><span class="text-gray-900 font-medium">${escapeHtml(data.username)}</span></div>
                <div><span class="font-semibold text-gray-700 block">Password:</span><span class="text-gray-900 font-medium">${'•'.repeat(data.password.length)} (${data.password.length} chars)</span></div>
                <div><span class="font-semibold text-gray-700 block">Role:</span><span class="text-gray-900 font-medium">${escapeHtml(data.role || 'N/A')}</span></div>
              </div>
              ${data.role === 'teacher' ? `<div class=\"grid grid-cols-1 md:grid-cols-3 gap-4\"><div><span class=\"font-semibold text-gray-700 block\">RFID:</span><span class=\"text-gray-900 font-medium\">${escapeHtml(data.rfid)}</span></div></div>` : ''}
              <p class="text-gray-700 text-sm pt-2 border-t border-gray-200">This employee will have login access to the selected role.</p>
            ` : `
              <div class="flex items-center gap-3 mb-2"><svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg><span class="font-semibold text-gray-900">Employee record only</span></div>
              <p class="text-gray-700 text-sm">No system account will be created. Employee will NOT have login access.</p>
            `}
          </div>
        </div>
      </div>
      <div class="bg-white border-t-2 border-gray-200 px-6 py-5 pb-8 flex justify-end gap-4">
        <button onclick="closeHRConfirmationModal()" class="px-8 py-3 border-2 border-gray-400 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors font-medium text-lg">Cancel</button>
        <button onclick="proceedWithCreation()" class="px-8 py-3 bg-gradient-to-r from-[#0B2C62] to-[#153e86] hover:from-[#153e86] hover:to-[#1e40af] text-white rounded-lg transition-all duration-200 flex items-center gap-3 font-bold text-lg shadow-lg hover:shadow-xl">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          <span>Confirm & Create Employee</span>
        </button>
      </div>
    </div>`;

    function escapeHtml(text) {
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    document.body.appendChild(wrapper);
    window.__hrAddEmpForm = data.form; // store ref
}

function closeHRConfirmationModal() {
    const modal = document.getElementById('hr-confirm-modal');
    if (modal) modal.remove();
    window.__hrAddEmpForm = null;
}

function proceedWithCreation() {
    if (window.__hrAddEmpForm) {
        const f = window.__hrAddEmpForm;
        closeHRConfirmationModal();
        f.submit();
    }
}

// Check for HR deletion approvals/rejections
// Initialize to current server time to avoid processing old approvals
let lastHRDeletionCheck = null;
let isInitialized = false;

// Show approval notification
function showApprovalNotification(employeeName, employeeId, approval) {
    const notif = document.getElementById('approvalNotification');
    const title = document.getElementById('approvalTitle');
    const message = document.getElementById('approvalMessage');
    
    if (!notif || !title || !message) return;
    
    // Update border color for approval (green)
    notif.querySelector('div').className = 'bg-white rounded-lg shadow-2xl p-6 max-w-md border-l-4 border-green-500';
    notif.querySelector('svg').className = 'w-6 h-6 text-green-500';
    notif.querySelector('svg').innerHTML = '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>';
    
    title.textContent = '✓ Request Approved!';
    message.innerHTML = `
        <div class="space-y-1">
            <p><strong>Your request has been processed</strong></p>
            <p><strong>Request:</strong> Delete Employee: ${employeeName}</p>
            <p><strong>Employee ID:</strong> ${employeeId}</p>
            <p><strong>Approved by:</strong> ${approval.reviewedBy || 'School Owner'}</p>
            <p><strong>Time:</strong> ${approval.reviewedAt || 'Just now'}</p>
            ${approval.ownerComments ? `<p><strong>Comments:</strong> ${approval.ownerComments}</p>` : ''}
        </div>
    `;
    
    notif.classList.remove('hidden');
    
    // Auto-hide after 8 seconds
    clearTimeout(window.__approvalTimer);
    window.__approvalTimer = setTimeout(() => {
        notif.classList.add('hidden');
    }, 8000);
}

// Show rejection notification
function showRejectionNotification(employeeName, employeeId, approval) {
    const notif = document.getElementById('approvalNotification');
    const title = document.getElementById('approvalTitle');
    const message = document.getElementById('approvalMessage');
    
    if (!notif || !title || !message) return;
    
    // Update border color for rejection (red)
    notif.querySelector('div').className = 'bg-white rounded-lg shadow-2xl p-6 max-w-md border-l-4 border-red-500';
    notif.querySelector('svg').className = 'w-6 h-6 text-red-500';
    notif.querySelector('svg').innerHTML = '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>';
    
    title.textContent = '✗ Request Rejected';
    message.innerHTML = `
        <div class="space-y-1">
            <p><strong>Your request has been rejected</strong></p>
            <p><strong>Request:</strong> Delete Employee: ${employeeName}</p>
            <p><strong>Employee ID:</strong> ${employeeId}</p>
            <p><strong>Rejected by:</strong> ${approval.reviewedBy || 'School Owner'}</p>
            <p><strong>Time:</strong> ${approval.reviewedAt || 'Just now'}</p>
            ${approval.ownerComments ? `<p><strong>Reason:</strong> ${approval.ownerComments}</p>` : ''}
        </div>
    `;
    
    notif.classList.remove('hidden');
    
    // Auto-hide after 8 seconds
    clearTimeout(window.__approvalTimer);
    window.__approvalTimer = setTimeout(() => {
        notif.classList.add('hidden');
    }, 8000);
}

async function checkHRDeletionApprovals() {
    try {
        // On first call, get current server time and don't process any approvals
        if (!isInitialized) {
            const response = await fetch(`../AdminF/check_approvals.php?last_check=${encodeURIComponent(new Date().toISOString())}`);
            const data = await response.json();
            if (data.success) {
                lastHRDeletionCheck = data.current_time;
                isInitialized = true;
                console.log('Initialized HR approval checking. Will check for approvals after:', lastHRDeletionCheck);
            }
            return;
        }
        
        const response = await fetch(`../AdminF/check_approvals.php?last_check=${encodeURIComponent(lastHRDeletionCheck)}`);
        const data = await response.json();
        
        if (data.success && data.approvals && data.approvals.length > 0) {
            console.log('Found NEW HR approvals:', data.approvals.length);
            data.approvals.forEach(approval => {
                // Only process HR employee deletion approvals/rejections
                if (approval.type === 'hr_employee_deletion' || approval.type === 'delete_hr_employee') {
                    const requestDetails = approval.requestDetails ? JSON.parse(approval.requestDetails) : {};
                    const targetData = approval.targetData ? JSON.parse(approval.targetData) : {};
                    const employeeId = targetData.employee_id || approval.target_id;
                    const employeeName = targetData.employee_name || (targetData.first_name + ' ' + targetData.last_name) || 'Employee';
                    
                    if (approval.status === 'approved') {
                        // Show approval notification
                        showApprovalNotification(employeeName, employeeId, approval);
                        
                        // Start fading out the row immediately
                        setTimeout(() => {
                            removeEmployeeRow(employeeId);
                        }, 100);
                    } else if (approval.status === 'rejected') {
                        // Show rejection notification
                        showRejectionNotification(employeeName, employeeId, approval);
                        
                        // Remove pending status from the row
                        updateRowPendingStatus(employeeId, false);
                    }
                }
            });
            
            // Update last check time
            lastHRDeletionCheck = data.current_time;
        }
    } catch (error) {
        console.error('Error checking HR deletion approvals:', error);
    }
}

// Remove employee row from table
function removeEmployeeRow(employeeId) {
    const table = document.querySelector('table tbody');
    if (!table) return;
    
    const rows = table.querySelectorAll('tr');
    rows.forEach(row => {
        const idCell = row.querySelector('td:first-child');
        if (!idCell) return;
        
        const idText = idCell.textContent.trim();
        if (idText.includes(employeeId)) {
            // Smooth fade out animation
            row.style.transition = 'opacity 1.3s ease-out, transform 1.3s ease-out';
            row.style.opacity = '0';
            row.style.transform = 'translateX(-20px)';
            
            // Remove after animation completes
            setTimeout(() => {
                row.remove();
                
                // Update total count
                const totalBadge = document.querySelector('.bg-\\[\\#0B2C62\\]');
                if (totalBadge) {
                    const match = totalBadge.textContent.match(/\d+/);
                    if (match) {
                        const currentCount = parseInt(match[0]);
                        totalBadge.textContent = `Total: ${currentCount - 1}`;
                    }
                }
            }, 1300);
        }
    });
}

// Check for pending deletion requests on page load
async function checkPendingDeletionRequests() {
    console.log('checkPendingDeletionRequests called');
    try {
        const response = await fetch('../AdminF/check_pending_requests.php');
        const data = await response.json();
        console.log('Pending requests response:', data);
        
        if (data.success && data.pending_requests) {
            console.log('Found pending requests:', data.pending_requests.length);
            data.pending_requests.forEach(request => {
                console.log('Processing request:', request);
                if (request.request_type === 'hr_employee_deletion' || request.request_type === 'delete_hr_employee') {
                    const targetData = request.target_data ? JSON.parse(request.target_data) : {};
                    const employeeId = targetData.employee_id || request.target_id;
                    console.log('HR deletion request for employee ID:', employeeId);
                    if (employeeId) {
                        updateRowPendingStatus(employeeId, true);
                    }
                }
            });
        } else {
            console.log('No pending requests found or request failed');
        }
    } catch (error) {
        console.error('Error checking pending requests:', error);
    }
}

// Start polling when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Starting HR deletion approval polling...');
    
    // Wait a bit for the table to fully render, then check for pending requests
    setTimeout(() => {
        checkPendingDeletionRequests();
    }, 500);
    
    // Check immediately on load
    checkHRDeletionApprovals();
    
    // Check for HR deletion approvals every 2 seconds
    setInterval(checkHRDeletionApprovals, 2000);
    
    // Also check for pending requests every 5 seconds to ensure consistency
    setInterval(checkPendingDeletionRequests, 5000);
});

</script>
<!-- Toast Notification -->
<div id="toast" class="fixed top-5 right-5 z-[99999] hidden">
  <div id="toastInner" class="px-4 py-3 rounded shadow-lg text-white"></div>
</div>

<!-- Approval/Rejection Notification -->
<div id="approvalNotification" class="fixed top-5 right-5 z-[9999] hidden">
  <div class="bg-white rounded-lg shadow-2xl p-6 max-w-md border-l-4 border-green-500">
    <div class="flex items-start">
      <div class="flex-shrink-0">
        <svg class="w-6 h-6 text-green-500" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
        </svg>
      </div>
      <div class="ml-3 flex-1">
        <h3 class="text-sm font-semibold text-gray-900" id="approvalTitle">Request Approved!</h3>
        <div class="mt-2 text-sm text-gray-600" id="approvalMessage"></div>
      </div>
      <button onclick="document.getElementById('approvalNotification').classList.add('hidden')" class="ml-4 text-gray-400 hover:text-gray-600">
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
        </svg>
      </button>
    </div>
  </div>
  <style>
    .toast-success { background: #16a34a; }
    .toast-error { background: #dc2626; }
  </style>
  <script>
    function showToast(message, type='success'){
      const t = document.getElementById('toast');
      const ti = document.getElementById('toastInner');
      ti.className = 'px-4 py-3 rounded shadow-lg text-white ' + (type==='success'?'toast-success':'toast-error');
      ti.textContent = message;
      t.classList.remove('hidden');
      clearTimeout(window.__toastTimer);
      window.__toastTimer = setTimeout(()=>{ t.classList.add('hidden'); }, 2000);
    }

    // Additional input validation
    // Function to setup input restrictions
    function setupInputRestrictions() {
      // Restrict name inputs to letters only and max 20 characters
      const nameInputs = document.querySelectorAll('.name-input');
      nameInputs.forEach(input => {
        // Remove old listener if exists
        input.removeEventListener('input', restrictToLetters);
        input.addEventListener('input', restrictToLetters);
      });

      // Restrict phone inputs to digits only and max 11 digits
      const phoneInputs = document.querySelectorAll('.phone-input');
      phoneInputs.forEach(input => {
        input.removeEventListener('input', restrictToDigits);
        input.addEventListener('input', restrictToDigits);
      });

      // Employee ID validation - numbers only, max 11 digits
      const empIdInput = document.querySelector('.employee-id-input');
      if (empIdInput) {
        empIdInput.removeEventListener('input', restrictToDigits11);
        empIdInput.addEventListener('input', restrictToDigits11);
      }
    }

    function restrictToLetters(e) {
      this.value = this.value.replace(/[^A-Za-z\s]/g, '').slice(0, 20);
    }

    function restrictToDigits(e) {
      this.value = this.value.replace(/[^0-9]/g, '').slice(0, 11);
    }

    function restrictToDigits11(e) {
      this.value = this.value.replace(/[^0-9]/g, '').slice(0, 11);
    }

    document.addEventListener('DOMContentLoaded', function() {
      setupInputRestrictions();
    });
    
    // ===== PREVENT BACK BUTTON AFTER LOGOUT =====
    window.addEventListener("pageshow", function(event) {
      if (event.persisted || (performance.navigation.type === 2)) window.location.reload();
    });
  </script>
</div>

<!-- Email Verification Modal -->
<div id="emailVerificationModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-[99999] flex items-center justify-center">
    <div class="bg-white rounded-2xl p-6 max-w-md w-full mx-4">
        <div class="flex flex-col items-center text-center">
            <div class="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center mb-3">
                <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">Verify Email Address</h3>
            <p class="text-gray-600 mb-4">Enter the 6-digit code sent to <span id="verificationEmailDisplay" class="font-semibold"></span></p>
            <input type="text" id="verificationCodeInput" maxlength="6" pattern="[0-9]{6}" class="w-full px-4 py-3 border border-gray-300 rounded-lg text-center text-2xl font-mono tracking-widest focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-2" placeholder="000000">
            <p id="verificationError" class="text-red-600 text-sm mb-4 hidden"></p>
            <p class="text-xs text-gray-500 mb-4">Code expires in <span id="verificationTimer">5:00</span></p>
        </div>
        <div class="flex gap-3">
            <button onclick="closeVerificationModal()" class="flex-1 px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-medium transition">
                Cancel
            </button>
            <button onclick="verifyEmailCode()" class="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition">
                Verify
            </button>
        </div>
        <button onclick="resendVerificationCode()" class="w-full mt-3 text-sm text-blue-600 hover:text-blue-700 font-medium">
            Resend Code
        </button>
    </div>
</div>

<script>
let verificationTimer;
let emailVerified = false;

function sendVerificationCode() {
    const emailInput = document.getElementById('employeeEmail');
    const email = emailInput.value.trim();
    
    // Validate email
    if (!email) {
        showToast('Please enter an email address', 'error');
        return;
    }
    
    if (!email.match(/@gmail\.com$/i)) {
        showToast('Only Gmail addresses are supported', 'error');
        return;
    }
    
    // Show loading
    const btn = document.getElementById('verifyEmailBtn');
    btn.disabled = true;
    btn.textContent = 'Sending...';
    
    // Send verification code
    fetch('send_verification_code.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `email=${encodeURIComponent(email)}`
    })
    .then(response => response.json())
    .then(data => {
        btn.disabled = false;
        btn.textContent = 'Verify Email';
        
        if (data.success) {
            // Show verification modal
            document.getElementById('verificationEmailDisplay').textContent = email;
            document.getElementById('emailVerificationModal').classList.remove('hidden');
            document.getElementById('verificationCodeInput').value = '';
            document.getElementById('verificationError').classList.add('hidden');
            
            // Start timer
            startVerificationTimer();
            
            // For testing - show code in console
            if (data.debug_code) {
                console.log('Verification code:', data.debug_code);
                showToast('Code sent! Check console for testing', 'success');
            } else {
                showToast('Verification code sent to ' + email, 'success');
            }
        } else {
            showToast(data.message || 'Failed to send verification code', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        btn.disabled = false;
        btn.textContent = 'Verify Email';
        showToast('An error occurred while sending verification code', 'error');
    });
}

function resendVerificationCode() {
    clearInterval(verificationTimer);
    sendVerificationCode();
}

function startVerificationTimer() {
    let timeLeft = 300; // 5 minutes
    const timerDisplay = document.getElementById('verificationTimer');
    
    clearInterval(verificationTimer);
    
    verificationTimer = setInterval(() => {
        timeLeft--;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            clearInterval(verificationTimer);
            timerDisplay.textContent = 'Expired';
            showToast('Verification code expired. Please request a new one.', 'error');
        }
    }, 1000);
}

function verifyEmailCode() {
    const email = document.getElementById('employeeEmail').value.trim();
    const code = document.getElementById('verificationCodeInput').value.trim();
    const errorDisplay = document.getElementById('verificationError');
    
    if (!code || code.length !== 6) {
        errorDisplay.textContent = 'Please enter a 6-digit code';
        errorDisplay.classList.remove('hidden');
        return;
    }
    
    // Verify code
    fetch('verify_email_code.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `email=${encodeURIComponent(email)}&code=${encodeURIComponent(code)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            emailVerified = true;
            clearInterval(verificationTimer);
            closeVerificationModal();
            
            // Update UI
            const statusDisplay = document.getElementById('emailVerificationStatus');
            statusDisplay.textContent = '✓ Email verified';
            statusDisplay.className = 'text-sm mt-1 font-medium text-green-600';
            
            const verifyBtn = document.getElementById('verifyEmailBtn');
            verifyBtn.textContent = 'Verified ✓';
            verifyBtn.disabled = true;
            verifyBtn.className = 'px-4 py-2 bg-green-600 text-white rounded-lg cursor-not-allowed whitespace-nowrap';
            
            showToast('Email verified successfully!', 'success');
        } else {
            errorDisplay.textContent = data.message || 'Invalid verification code';
            errorDisplay.classList.remove('hidden');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        errorDisplay.textContent = 'An error occurred while verifying code';
        errorDisplay.classList.remove('hidden');
    });
}

function closeVerificationModal() {
    document.getElementById('emailVerificationModal').classList.add('hidden');
    clearInterval(verificationTimer);
}

// Update form validation to check email verification
const originalConfirmAddEmployee = window.confirmAddEmployee;
window.confirmAddEmployee = function() {
    const email = document.getElementById('employeeEmail').value.trim();
    
    if (email.match(/@gmail\.com$/i) && !emailVerified) {
        showToast('Please verify your Gmail address before submitting', 'error');
        return;
    }
    
    // Call original function
    if (originalConfirmAddEmployee) {
        originalConfirmAddEmployee();
    }
};
</script>

</body>
</html>


