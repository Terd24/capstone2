<?php
// This file handles adding new HR employees for Super Admin
// Based on HRF/add_employee.php but specifically for HR accounts
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include '../StudentLogin/db_conn.php';
include '../includes/log_system_notification.php';

// Require Super Admin login
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'superadmin') {
    header("Location: ../StudentLogin/login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Employee information
    $id_number = trim($_POST['id_number']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name']);
    $position = trim($_POST['position']);
    $department = trim($_POST['department']); // Will always be "Human Resources"
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $hire_date = $_POST['hire_date'];
    $create_account = true; // Always create account (mandatory)
    
    // Account information (always required)
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = 'hr'; // Always HR for Super Admin

    try {
        // Start transaction
        $conn->begin_transaction();

        // Ensure employees table exists (and required columns)
        $table_check = $conn->query("SHOW TABLES LIKE 'employees'");
        if ($table_check->num_rows == 0) {
            $create_employees_table = "CREATE TABLE employees (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_number VARCHAR(20) UNIQUE NOT NULL,
                first_name VARCHAR(50) NOT NULL,
                middle_name VARCHAR(50),
                last_name VARCHAR(50) NOT NULL,
                position VARCHAR(100) NOT NULL,
                department VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                address TEXT NOT NULL,
                hire_date DATE NOT NULL,i revret it becuase 
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";
            $conn->query($create_employees_table);
        } else {
            // Update id_number column to support longer IDs (CCI2025-0001 format)
            $id_column = $conn->query("SHOW COLUMNS FROM employees LIKE 'id_number'")->fetch_assoc();
            if ($id_column && strpos($id_column['Type'], 'varchar(11)') !== false) {
                $conn->query("ALTER TABLE employees MODIFY COLUMN id_number VARCHAR(20) UNIQUE NOT NULL");
            }
            
            // Add missing columns if needed
            $column_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'hire_date'");
            if ($column_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN hire_date DATE NOT NULL DEFAULT '2024-01-01'");
            }
            $middle_name_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'middle_name'");
            if ($middle_name_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN middle_name VARCHAR(50) NULL AFTER first_name");
            }
            $address_check = $conn->query("SHOW COLUMNS FROM employees LIKE 'address'");
            if ($address_check->num_rows == 0) {
                $conn->query("ALTER TABLE employees ADD COLUMN address TEXT NULL");
            }
        }

        // Validations
        if (!preg_match('/^[0-9A-Za-z\-]+$/', $id_number) || strlen($id_number) > 20) {
            throw new Exception("Employee ID must contain only letters, numbers, and dashes and be maximum 20 characters.");
        }
        if (empty($email)) {
            throw new Exception("Email is required.");
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Please enter a valid email address.");
        }
        
        // Validate email domain - only allow trusted providers
        $allowedDomains = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'icloud.com', 'protonmail.com', 'aol.com', 'zoho.com', 'mail.com', 'yandex.com', 'gmx.com', 'tutanota.com'];
        $emailDomain = strtolower(substr(strrchr($email, "@"), 1));
        if (!in_array($emailDomain, $allowedDomains)) {
            throw new Exception("Please use a valid email provider (Gmail, Yahoo, Outlook, etc.)");
        }
        // Clean phone number (remove +63 and formatting)
        $phone_clean = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone_clean) == 12 && substr($phone_clean, 0, 2) == '63') {
            // Convert +63 9XX XXX XXXX to 09XX XXX XXXX
            $phone = '0' . substr($phone_clean, 2);
        } else if (strlen($phone_clean) == 11 && substr($phone_clean, 0, 1) == '0') {
            $phone = $phone_clean;
        } else {
            throw new Exception("Phone must be in format +63 9XX-XXX-XXXX or 09XX-XXX-XXXX");
        }
        if (empty($address)) {
            throw new Exception("Complete Address is required.");
        }
        if (strlen($address) < 20) {
            throw new Exception("Complete address must be at least 20 characters long.");
        }
        if (strlen($address) > 500) {
            throw new Exception("Complete address must not exceed 500 characters.");
        }
        // Validate address has at least 4 components separated by commas
        $addressParts = array_filter(array_map('trim', explode(',', $address)), function($part) {
            return strlen($part) > 0;
        });
        if (count($addressParts) < 4) {
            throw new Exception("Complete address must include at least 4 components separated by commas (e.g., Street, Barangay, City, Province)");
        }
        
        // Account fields validation (now mandatory)
        if (empty($username) || trim($username) === '') {
            throw new Exception("Username is required for system account.");
        }
        if (empty($password)) {
            throw new Exception("Password is required for system account.");
        }

        // Check if employee ID already exists
        $check_stmt = $conn->prepare("SELECT id_number FROM employees WHERE id_number = ?");
        $check_stmt->bind_param("s", $id_number);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            throw new Exception("Employee ID already exists.");
        }

        // Insert employee
        $stmt = $conn->prepare("INSERT INTO employees (id_number, first_name, middle_name, last_name, position, department, email, phone, address, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssss", $id_number, $first_name, $middle_name, $last_name, $position, $department, $email, $phone, $address, $hire_date);
        if (!$stmt->execute()) {
            throw new Exception("Failed to add employee: " . $stmt->error);
        }

        // Always create a system account (mandatory for HR employees)
        if ($username && $password) {
            // Ensure employee_accounts table exists
            $account_table_check = $conn->query("SHOW TABLES LIKE 'employee_accounts'");
            if ($account_table_check->num_rows == 0) {
                $create_accounts_table = "CREATE TABLE employee_accounts (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    employee_id VARCHAR(20) NOT NULL,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    role ENUM('registrar','cashier','guidance','attendance','hr','teacher') NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (employee_id) REFERENCES employees(id_number) ON DELETE CASCADE
                )";
                $conn->query($create_accounts_table);
            }
            // Ensure ENUM includes hr
            $roleColumn = $conn->query("SHOW COLUMNS FROM employee_accounts LIKE 'role'")->fetch_assoc();
            if ($roleColumn && isset($roleColumn['Type'])) {
                if (strpos($roleColumn['Type'], "'hr'") === false) {
                    $conn->query("ALTER TABLE employee_accounts MODIFY role ENUM('registrar','cashier','guidance','attendance','hr','teacher') NOT NULL");
                }
            }

            // Check if username already exists
            $username_check = $conn->prepare("SELECT username FROM employee_accounts WHERE username = ?");
            $username_check->bind_param("s", $username);
            $username_check->execute();
            if ($username_check->get_result()->num_rows > 0) {
                throw new Exception("Username already exists.");
            }

            // Hash password and insert
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $account_stmt = $conn->prepare("INSERT INTO employee_accounts (employee_id, username, password, role) VALUES (?, ?, ?, ?)");
            $account_stmt->bind_param("ssss", $id_number, $username, $hashed_password, $role);
            if (!$account_stmt->execute()) {
                throw new Exception("Failed to create account: " . $account_stmt->error);
            }
        }

        // Commit the transaction - add employee immediately without approval
        $conn->commit();
        
        // Log system notification for Owner
        try {
            $employee_name = $first_name . ' ' . $last_name;
            $admin_name = $_SESSION['superadmin_name'] ?? 'Super Admin';
            $notif_title = "New HR Employee Added";
            $notif_message = formatActionMessage('employee_added', $employee_name, $id_number);
            
            $new_data = [
                'name' => $employee_name,
                'id_number' => $id_number,
                'position' => $position,
                'department' => $department,
                'role' => $role ?? 'N/A'
            ];
            
            $notif_result = logSystemNotification(
                $conn,
                $notif_title,
                $notif_message,
                'success',
                'Super Admin',
                $admin_name,
                'Super Admin',
                'employee_added',
                'employees',
                $id_number,
                null,
                $new_data
            );
            
            if (!$notif_result) {
                error_log("Failed to log notification for employee add: " . $id_number);
            }
        } catch (Exception $notif_error) {
            error_log("Error logging notification: " . $notif_error->getMessage());
        }
        
        // Return JSON response for AJAX
        echo json_encode([
            'success' => true,
            'message' => 'HR Employee added successfully!',
            'employee' => [
                'id_number' => $id_number,
                'first_name' => $first_name,
                'middle_name' => $middle_name,
                'last_name' => $last_name,
                'position' => $position,
                'department' => $department,
                'email' => $email,
                'phone' => $phone,
                'hire_date' => $hire_date,
                'username' => $username ?? null
            ]
        ]);
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        
        // Return JSON error response for AJAX
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
        error_log("HR Employee creation error: " . $e->getMessage());
        error_log("POST data: " . print_r($_POST, true));
        exit;
    }
}
?>
