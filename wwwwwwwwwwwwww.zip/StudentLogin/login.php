<?php
session_start();
require_once 'db_conn.php';

// Check if system is in maintenance mode
function is_maintenance_mode($conn) {
    // Ensure system_config table exists
    $conn->query("CREATE TABLE IF NOT EXISTS system_config (
        config_key VARCHAR(50) PRIMARY KEY,
        config_value TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    $result = $conn->query("SELECT config_value FROM system_config WHERE config_key = 'maintenance_mode'");
    if ($result && $row = $result->fetch_assoc()) {
        return ($row['config_value'] == '1' || $row['config_value'] === 'enabled');
    }
    return false;
}

// Check maintenance mode for non-superadmin users
if (is_maintenance_mode($conn)) {
    // Allow superadmin to bypass maintenance mode
    if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'superadmin') {
        // Show maintenance page for all other users
        ?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Maintenance - Cornerstone College Inc.</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div class="mb-6">
            <img src="../images/LogoCCI.png" alt="Cornerstone College Inc." class="h-20 w-20 mx-auto rounded-full bg-blue-100 p-2">
        </div>
        <div class="mb-6">
            <svg class="w-16 h-16 mx-auto text-amber-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/>
            </svg>
            <h1 class="text-2xl font-bold text-gray-800 mb-2">System Under Maintenance</h1>
            <p class="text-gray-600 mb-4">We're currently performing system maintenance to improve your experience.</p>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <p class="text-blue-800 text-sm">
                    <strong>Cornerstone College Inc.</strong><br>
                    The system will be back online shortly. Please try again later.
                </p>
            </div>
        </div>
        <div class="text-sm text-gray-500 mb-6">
            <p>If you need immediate assistance, please contact the IT department.</p>
        </div>
        
        <!-- Admin/Owner Login Button -->
        <div class="border-t border-gray-200 pt-4">
            <p class="text-gray-600 text-sm mb-2">System Administrator Access</p>
            <button onclick="location.href='../admin_login.php'" 
                    class="text-purple-600 hover:text-purple-700 font-medium text-sm hover:underline">
                🔧 Admin/Owner Login
            </button>
        </div>
    </div>
</body>
</html><?php
        exit;
    }
}

// 🚫 If already logged in, redirect directly to dashboard
if (isset($_SESSION['role'])) {
    $role = strtolower($_SESSION['role']);
    
    // All employees should use admin_login.php
    if (in_array($role, ['superadmin', 'owner', 'hr', 'registrar', 'cashier', 'guidance', 'attendance', 'teacher', 'department_head'])) {
        session_destroy();
        header("Location: ../admin_login.php");
        exit;
    }
    
    // Students and parents
    switch ($role) {
        case 'student':
            header("Location: studentDashboard.php");
            exit;
        case 'parent':
            header("Location: ../ParentLogin/ParentDashboard.php");
            exit;
    }
}

// ❌ Stop caching (important for Back button issue)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// Helper: log successful logins for reporting (Super Admin dashboard)
function log_login($conn, $userType, $idNumber, $username, $role) {
    // Create table if not exists (idempotent)
    $conn->query("CREATE TABLE IF NOT EXISTS login_activity (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_type VARCHAR(20) NOT NULL,
        id_number VARCHAR(50) NOT NULL,
        username VARCHAR(100) NOT NULL,
        role VARCHAR(50) NOT NULL,
        login_time DATETIME NOT NULL,
        session_id VARCHAR(128) NULL,
        INDEX idx_login_date (login_time),
        INDEX idx_id_number (id_number)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if ($stmt = $conn->prepare("INSERT INTO login_activity (user_type, id_number, username, role, login_time, session_id) VALUES (?,?,?,?,NOW(),?)")) {
        $sid = session_id();
        $stmt->bind_param('sssss', $userType, $idNumber, $username, $role, $sid);
        $stmt->execute();
        $stmt->close();
    }
}

// 🔑 Handle login submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json');

    // Debug logging
    error_log("Login attempt received at " . date('Y-m-d H:i:s'));

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    error_log("Username received: '" . $username . "'");
    error_log("Password length: " . strlen($password));

    if (empty($username) || empty($password)) {
        error_log("Empty username or password");
        echo json_encode(['status'=>'error','message'=>'Please enter both username and password.']);
        exit;
    }

    $usernameFound = false;

    // 1️⃣ Try student
    $stmt = $conn->prepare("SELECT * FROM student_account WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $usernameFound = true;
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['student_id'] = $row['id'];
            $_SESSION['id_number'] = $row['id_number'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['student_name'] = $row['first_name'] . ' ' . $row['last_name'];
            $_SESSION['full_name'] = $row['first_name'] . ' ' . $row['last_name'];
            $_SESSION['program'] = $row['academic_track'] ?? 'N/A';
            $_SESSION['year_section'] = $row['grade_level'] ?? 'N/A';
            $_SESSION['first_name'] = $row['first_name'];
            $_SESSION['last_name'] = $row['last_name'];
            $_SESSION['grade_level'] = $row['grade_level'];
            $_SESSION['role'] = 'student';
            
            // Check if student must change password (first-time login)
            $must_change = $row['must_change_password'] ?? 1; // Default to 1 if column doesn't exist
            
            // Log student login
            log_login($conn, 'student', $row['id_number'], $row['username'], 'student');
            
            // Redirect to password change if first-time login
            if ($must_change == 1) {
                $_SESSION['must_change_password'] = true;
                echo json_encode(['status'=>'success','redirect'=>'change_password.php']);
            } else {
                echo json_encode(['status'=>'success','redirect'=>'studentDashboard.php']);
            }
            exit;
        }
    }

    // 2️⃣ SuperAdmin and Owner accounts are now handled in admin_login.php only

    // 2️⃣ Try parent
    $stmt = $conn->prepare("SELECT * FROM parent_account WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $usernameFound = true;
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['parent_id'] = $row['parent_id'];
            $_SESSION['id_number'] = $row['id_number'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['parent_name'] = $row['first_name'] . ' ' . $row['last_name'];
            $_SESSION['first_name'] = $row['first_name'];
            $_SESSION['last_name'] = $row['last_name'];
            $_SESSION['child_id'] = $row['child_id'];
            $_SESSION['child_name'] = $row['child_name'];
            $_SESSION['role'] = 'parent';
            echo json_encode(['status' => 'success','redirect' => '../ParentLogin/ParentDashboard.php']);
            exit;
        }
    }


    // Final decision
    if ($usernameFound) {
        error_log("Username found but password incorrect for: " . $username);
        echo json_encode(['status'=>'error','message'=>'Incorrect password.']);
    } else {
        error_log("Username not found in any table: " . $username);
        echo json_encode(['status'=>'error','message'=>'Username not found.']);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Student Login - Cornerstone College Inc.</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="../images/LogoCCI.png">
  <link rel="manifest" href="/manifest.webmanifest">
  <meta name="theme-color" content="#0B2C62">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <meta name="apple-mobile-web-app-title" content="CCI">
  <meta name="description" content="Cornerstone College Inc. Student Portal - Access grades, documents, and academic records">
  <meta name="keywords" content="student, grades, academic, cornerstone college, portal">
  <meta name="author" content="Cornerstone College Inc.">
  <script>
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch(console.error);
      });
    }
  </script>
  <style>
    .school-gradient { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 50%, #1e40af 100%); }
    .card-shadow { box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
    .logo-glow { filter: drop-shadow(0 0 20px rgba(59, 130, 246, 0.3)); }

    /* PWA Install Prompt Enhancement */
    .pwa-install-banner {
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #0B2C62;
      color: white;
      padding: 15px 25px;
      border-radius: 25px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      z-index: 1000;
      display: none;
      animation: slideUp 0.3s ease-out;
    }

    @keyframes slideUp {
      from { transform: translateX(-50%) translateY(100px); opacity: 0; }
      to { transform: translateX(-50%) translateY(0); opacity: 1; }
    }

    .pwa-install-banner button {
      background: white;
      color: #0B2C62;
      border: none;
      padding: 8px 16px;
      border-radius: 20px;
      font-weight: bold;
      margin-left: 15px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .pwa-install-banner button:hover {
      background: #f3f4f6;
      transform: scale(1.05);
    }
  </style>

  <!-- JavaScript Functions (moved before body) -->
  <script>
    // Clear form when page loads (prevents back button from showing cached data)
    function clearFormOnLoad() {
        document.getElementById("usernameInput").value = "";
        document.getElementById("passwordInput").value = "";
    }

    // Prevent form caching
    window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
            clearFormOnLoad();
        }
    });

    // Toggle password visibility
    function togglePassword() {
      const passwordInput = document.getElementById("passwordInput");
      const eyeIcon = document.getElementById("eyeIcon");

      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        // Add diagonal line through eye
        eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path><line x1="4" y1="4" x2="20" y2="20" stroke-linecap="round"></line>';
      } else {
        passwordInput.type = "password";
        // Eye without line
        eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>';
      }
    }

    // PWA Install Prompt
    let deferredPrompt;
    const installBanner = document.getElementById('pwaInstallBanner');

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      if (installBanner) {
        installBanner.style.display = 'flex';
      }
    });

    async function installPWA() {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted' && installBanner) {
          installBanner.style.display = 'none';
        }
        deferredPrompt = null;
      }
    }

    // Hide banner if PWA is already installed
    window.addEventListener('appinstalled', () => {
      if (installBanner) {
        installBanner.style.display = 'none';
      }
    });

    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', function() {
      document.getElementById("loginForm").addEventListener("submit", function(e) {
        e.preventDefault();
        const username = document.getElementById("usernameInput").value;
        const password = document.getElementById("passwordInput").value;

        // Show loading state
        const submitBtn = document.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Signing In...';
        submitBtn.disabled = true;

        fetch('login.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
        })
        .then(res => {
          console.log('Response status:', res.status);
          if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
          }
          return res.json();
        })
        .then(data => {
          console.log('Login response:', data);
          if (data.status === 'success') {
            window.location.href = data.redirect;
          } else {
            const errorDiv = document.getElementById('errorMessage');
            errorDiv.textContent = data.message;
            errorDiv.classList.remove('hidden');
          }
        })
        .catch(error => {
          console.error('Login error:', error);
          const errorDiv = document.getElementById('errorMessage');
          errorDiv.textContent = 'Connection error. Please check if server is running and try again.';
          errorDiv.classList.remove('hidden');
        })
        .finally(() => {
          // Restore button
          submitBtn.textContent = originalText;
          submitBtn.disabled = false;
        });
      });
    });
  </script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center p-4" onload="clearFormOnLoad()">

  <div class="w-full max-w-md">
    <!-- Back to Home Button -->
    <div class="mb-6">
      <a href="../index.php" class="inline-flex items-center px-4 py-2 text-gray-600 hover:text-gray-800 hover:bg-white/50 rounded-lg transition-all group backdrop-blur-sm">
        <svg class="w-4 h-4 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
        </svg>
        <span class="text-sm font-medium">Back to Home</span>
      </a>
    </div>

    <!-- Header -->
    <div class="text-center mb-8">
      <img src="../images/LogoCCI.png" alt="Cornerstone College Inc." class="w-20 h-20 mx-auto mb-4">
      <h1 class="text-2xl font-bold text-gray-800">Cornerstone College Inc.</h1>
      <p class="text-gray-600 text-sm">Student & Parent Portal</p>
    </div>

    <!-- Login Card -->
    <div class="bg-white rounded-2xl card-shadow p-8">
      <div class="text-center mb-6">
        <h2 class="text-xl font-semibold text-gray-800 mb-2">Welcome Back</h2>
        <p class="text-gray-600 text-sm">Sign in to access your account</p>
      </div>
      <form id="loginForm" class="space-y-5">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
          <input id="usernameInput" type="text" placeholder="Enter your username" autocomplete="off"
                 class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" required>
        </div>
        <div class="relative">
          <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
          <input id="passwordInput" type="password" placeholder="Enter your password" autocomplete="off"
                 class="w-full px-4 py-3 border border-gray-300 rounded-xl pr-12 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all" required>
          <button type="button" onclick="togglePassword()" class="absolute right-4 top-10 text-gray-400 hover:text-gray-600 transition-colors focus:outline-none">
            <svg id="eyeIcon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
            </svg>
          </button>
        </div>
        
        <div id="errorMessage" class="hidden bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm"></div>
        
        <button type="submit" class="w-full bg-[#0B2C62] text-white py-3 rounded-xl font-semibold hover:opacity-90 transition-all transform hover:scale-[1.02]">
          Sign In
        </button>
      </form>
      
      <div class="text-center mt-6 pt-6 border-t border-gray-200">
        <p class="text-gray-600 text-sm mb-2">Are you a parent or guardian?</p>
        <button onclick="location.href='../ParentLogin/ParentLogin.php'" 
                class="text-blue-600 hover:text-blue-600 font-medium text-sm hover:underline">
          Parent/Guardian Portal
        </button>
      </div>
    </div>
  </div>

  <!-- PWA Install Banner -->
  <div id="pwaInstallBanner" class="pwa-install-banner">
    <div>
      <strong>📱 Install CCI</strong><br>
      <small>Add to home screen for quick access</small>
    </div>
    <button onclick="installPWA()">Install</button>
  </div>

</body>
</html>
